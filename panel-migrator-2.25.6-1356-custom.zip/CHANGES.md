# 2.25.6 (31 July 2024)

* [*] Plesk Migrator v1.7.6 will be the last Plesk Migrator update that supports Plesk versions older than Plesk 18.0.60. To continue receiving Plesk Migrator updates with bugfixes and new features, please update your Plesk installation to version 18.0.60 or higher.

# 2.25.5 (5 June 2024)

* [-] Fixed the issue with migrating domain pointers from Direct Admin. (PMT-5311)
* [-] Fixed the issue with migrating subdomains from Direct Admin. (PMT-5312)

# 2.25.4 (27 May 2024)

* [-] No more PHP deprecation errors in Plesk 18.0.53 when migrating subscription. (PMT-5306)

# 2.25.3 (14 May 2024)

* [+] Added support for Ubuntu 24.04.

# 2.25.2 (21 December 2023)

* [-] Migration no longer fails to create mailboxes for subscriptions with suspended owner (PMT-5002)

# 2.25.1 (28 November 2023)

* [*] Internal improvements

# 2.25.0 (20 November 2023)

* [*] The extension can now be installed on Plesk servers running on Debian 12.
* [*] Internal improvements

# 2.24.1 (10 July 2023)

* [-] The extension now correctly gathers the list of chroot directories to migrate. (PMT-5178)
* [*] Internal improvements

# 2.24.0 (18 February 2023)

* [*] Internal improvements

# 2.23.0 (12 December 2022)

* [-] Migration no longer fails to authenticate some Microsoft SQL servers. (PMT-5064)

# 2.22.4 (14 October 2022)

* [-] Running the `apt update` command on a Plesk server with both the Plesk Migrator and Site Import extensions installed no longer results in a large number of unnecessary warning messages. (PMT-4794)

# 2.22.3 (6 October 2022)

* [-] Migration of MySQL/MariaDB databases from Windows servers no longer fails. (PMT-5056)

# 2.22.2 (30 September 2022)

* [-] Migration of MySQL/MariaDB databases from DirectAdmin servers or custom panel Linux servers no longer fails with the “Permission denied” error. (PMT-5055)

# 2.22.1 (20 September 2022)

* [-] Migration no longer fails with the "Character set 'utf8mb4' is not a compiled character set" error when migrating from outdated MySQL/MariaDB servers. (PMT-5050)

# 2.22.0 (29 August 2022)

* [*] The extension can now be installed on Plesk servers running on Red Hat Enterprise Linux 9.
* [-] Website content is no longer corrupted during migration when UTFmb4 symbols are used. (PMT-5047)

# 2.21.8 (23 May 2022)

* [*] Updated translations.

# 2.21.7 (29 March 2022)

* [*] Internal improvements.

# 2.21.6 (23 March 2022)

* [*] The extension can now be installed on Plesk servers running on Ubuntu 22.04.
* [-] If SSH key based authentication is chosen, the extension now offers a list of options helping to resolve the issue in case of incompatible SSH keys instead of simply failing. (PMT-5018)
 
# 2.21.5 (21 February 2022)

* [*] The extension can now be installed in Plesk on Debian 11.
* [-] The extension can now connect to source servers that have old versions of OpenSSH even if the servers do not provide correct information on key hashing algorithms. (PMT-5008)

# 2.21.4 (17 January 2022)

* [-] The extension can now correctly resync email messages from cPanel. (PMT-5000) 
* [-] Migration from servers with customized SSH MACs now works. (PMT-4361)
* [-] Plesk in Restricted Mode no longer shows the "Migration & Transfer Manager" button in "Tools & Settings". (PMT-5001)
  **Note:** To have this bugfix come into effect, update your Plesk to the upcoming version 18.0.41.

# 2.21.3 (29 November 2021)
 
* [-] Migrator no longer fails to copy the content and system files of domains that have mixed case names. (PMT-4963)

# 2.21.2 (27 July 2021)

* [-] When migrating mail via IMAP between Plesk for Windows servers, mail in subfolders is now being correctly copied over to the destination server. (PMT-4943)
* [-] Plesk Migrator no longer incorrectly reports errors during post-check after migrating one or more DNS records containing long text fields. (PMT-4952)
* [-] Migrating a subscription with the mail service disabled no longer results in the mail service being enabled on the destination server. (PMT-4870)
* [-] Migration no longer fails when migrating one or more plans with leading and/or trailing whitespace characters in the name. (PMT-2776)
* [-] Migrating from Debian 10 servers no longer fails with the "Source server OS is not supported" error. (PMT-4974)

# 2.21.1 (18 June 2021)

* [+] Migration post-check no longer reports an issue if the HTTP response code changed from 200 on the source server to 301 on the target server due to the 'Permanent SEO-safe 301 redirect from HTTP to HTTPS' option being enabled by default on Plesk Obsidian.
* [-] Migrating From Plesk Obsidian for Linux 18.0.36 no longer results in the "Failed to create the remote configuration dump on the target server. Not all settings may be migrated." error during pre-check, which could lead to some settings not being transferred during migration. (PMT-4957)
* [-] Migrating from Confixx with a recent Perl version installed no longer fails with the "Failed to perform action: Fetch data from source Confixx" error. (PMT-4960)
* [-] The value of the 'Permanent SEO-safe 301 redirect from HTTP to HTTPS' option is now transferred over correctly when migrating from cPanel to Plesk Obsidian. (PMT-4611)
* [-] Migrating a domain with an APS application installed on the domain root with the "HTTPS" option enabled no longer results in misleading cautions during post-check. (PMT-4913)
* [-] CLI migration to a Plesk for Linux server with MariaDB 10.5 installed no longer fails with the "Service 'mysql' is not started on target Plesk server" error. (PMT-4935)
* [-] Plesk Migrator can now correctly decrypt passwords if the PLESK_BACKUP_PASSWORD environment variable is set on the source server. (PMT-4953)
* [-] The extension no longer corrupts the names of mail folders that contain non-ASCII characters during migration. (PMT-4958)
* [-] Replaced the missing `warning.png` and `ok.png` icons. (PMT-4933)

# 2.21.0 (13 April 2021)

* [+] It is now possible to migrate Plesk servers with remote databases.
* [+] It is now possible to migrate servers on AlmaLinux OS. 
* [-] It is now again possible to migrate cPanel servers with Perl version 5.21.3 and later installed. (PMT-4911) 
* [-] It is now possible to migrate Plesk 12.5 servers that have WordPress websites. (PMT-4921)
* [-] The extension can no longer migrate additional users to a wrong subscription that belongs to the same owner. (PMT-4759)
* [-] Migration via the CLI no longer fails if a service or add-on plan to be migrated has no subscriptions. (PMT-4888)
* [-] It is now again possible to migrate subscriptions that belong to one hosting plan. (PMT-4915)
* [-] The extension no longer migrates settings specified on the "Performance" tab of a hosting plan.
Such migration caused an error because the "Performance" tab of hosting plans was removed in Plesk Obsidian. (PMT-4827)
* [-] If nginx is turned off on the source server, migration no longer resets PHP handlers. (PMT-4861)
* [-] The extension no longer limits the user name length of password-protected directories to 20 characters. (PMT-4893)
* [-] Migration no longer fails if the dump import was finished with the error code 152. (PMT-4909)
* [-] The extension now correctly detects the remoteip Apache module. (PMT-4914)

# 2.20.3 (25 January 2021)

* [+] Added MySQL 8 support.

# 2.20.2 (30 December 2020)

* [*] Improved processing of encrypted data in backups.
* [-] Plesk Migrator no longer tries to migrate content of disabled mail accounts. (PMT-4756)
* [-] Plesk Migrator no longer tries to migrate hidden Plesk extensions. (PMT-4790)
* [-] Customers' and resellers' login names that contain digits are now shown in the Plesk Migrator interface. (PMT-4791)
* [-] Improved mail migration stability. (PMT-4865)
* [-] In Plesk for Linux, Plesk Migrator can now migrate databases whose tables have the `ROW_FORMAT=FIXED` option. (PMT-4814)
* [-] In Plesk for Linux, migration no longer fails when the `HTTPD_VHOSTS_D` variable contains capital letters. (PMT-4863) 
* [-] In Plesk for Windows, ODBC DSN connections are no longer false positively marked as "failed" after migration. (PMT-4824)

# 2.20.1 (28 October 2020)

* [-] Migration from DirectAdmin no longer occasionally fails to be started. (PMT-4848)
* [-] Migration from cPanel to Plesk on CentOS 8 now preserves group and other permissions. (PMT-4840)
* [-] Migration to a remote Microsoft SQL server no longer fails with the "AttributeError: 'NoneType" error. (PMT-4852)
* [-] Improved the interface error reporting when `config.ini` does not contain mandatory parameters. (PMT-4856, PMT-4857)

# 2.20.0 (14 October 2020)

* [+] External IDs of customers, resellers, and subscriptions can now be migrated in the extension's interface.
Previously, it was possible to migrate external IDs only via the CLI. 
* [-] It is now possible to install the extension in Plesk on CloudLinux that has LVE Manager installed. (PMT-3777, PMT-4832)
* [-] Migration of WordPress applications from Plesk 12.5 to Plesk Obsidian no longer fails with the
"Element 'wordpress-instance': This element is not expected." error. (PMT-4712)
* [-] If the source DirectAdmin server has MySQL 5.7 or later, the extension now migrates database users without any errors. (PMT-4746) 
* [-] Mail migration from DirectAdmin now works for accounts not owned by the administrator. (PMT-4816)
* [-] Migration of Microsoft SQL 2019 databases no longer fails with the "Access is denied" error. (PMT-4817)
* [-] Email messages migrated twice are no longer displayed as source code. (PMT-4820) 
* [-] In Plesk for Windows, permissions of FTP users are now completely migrated. (PMT-4821)

# 2.19.6 (23 July 2020)

* [*] The extension can now migrate large mailboxes (more than 2 GB) to SmarterMail at a time.
* [-] Fixed the following issues that could occasionally happen if the target mail server uses IMAP to restore mail (for example, SmarterMail 100 or later):
    * Texts of email messages were not migrated completely.
    * Errors occurred when the emails were restored on the target mail server. (PMT-4768)
* [-] Migration now works if the source server has freshly installed cPanel of the latest version. (PMT-4795)

# 2.19.5 (29 June 2020)

* [*] The extension can now be installed in Plesk on Debian 10.
* [-] When migrating a domain secured with an SSL/TLS certificate from Direct Admin, the certificate is now correctly selected in Plesk after migration. (PMT-4789)
* [-] Emails migrated to SmarterMail 100 no longer have their sending and delivery dates replaced with the date of migration in the SmarterMail web interface. (PMT-4786)

# 2.19.4 (15 May 2020)

* [-] On Linux servers now possible to migrate subscriptions contains additional Apache/nginx directives into Plesk 18.0.27. (PMT-4783)

# 2.19.3 (14 May 2020)

* [-] Migration now works in Plesk 18.0.27 and later. (PMT-4781)

# 2.19.2 (2 April 2020)

* [-] Migration now works if the source or target server is remote SmarterMail 100. (PMT-4754)
* [-] Improved stability of migration if the target server is remote SmarterMail 100. (PMT-4760)
* [-] If the protected directory name contains the dot (.) character, the name of the protected directory user 
is no longer changed during migration. (PMT-3317)

# 2.19.1 (18 March 2020)

* [-] If a database that is being migrated already exists on the target server but not registered in Plesk, 
the database is no longer overwritten with one from the source server. 
Plesk now detects such issues, does not migrate the database, and shows a warning message. (PMT-4723)
* [-] Migration from cPanel no longer fails if a password of the source database server is enclosed in single quotes. (PMT-4751)

# 2.19.0 (11 March 2020)

* [+] The extension can now migrate mail if the source mail server is SmarterMail 100.
* [+] The extension can now be installed in Plesk on CentOS 8.
* [-] After migrating mail, actual dates when emails were received are no longer changed to the date of migration on certain mail clients (for example Apple Mail). (PMT-4559)

# 2.18.0 (20 January 2020)

* [+] When migrating from cPanel to Plesk, DNS records are now migrated as well.
* [-] When migrating from DirectAdmin to Plesk, SSL is now enabled on the target servers for domains that had SSL enabled on the source server. (PMT-4684)
* [-] Migration from cPanel to Plesk no longer fails if one or more reseller-owned domains are being migrated and resellers are not supported on the target server (for example, because the Plesk administrator is in Power User view or because a license other than the Web Host Edition license is installed on the target server). (PMT-4691)
* [-] Gave the field for the IP address of the source server on the "New Migration" a more descriptive name. (PMT-4705)

# 2.17.8 (14 October 2019)

* [*] Migrating from cPanel servers hosting a large number of domains using the Plesk Migrator GUI has been sped up considerably.
* [-] It is now possible to migrate from cPanel by hosting plan as well as by subscription or owner using the Migrator GUI. (PMT-4642)
* [-] It is now possible to migrate from cPanel even if the `/var/cpanel/users` directory contains one or more files or a directories with special symbols in the name (for example, ")"). (PMT-4660)
* [-] Transferring web content of a domain hosted on Parallels Pro Control Panel for Linux no longer fails if the domain has a subdomain and the subdomain does not have CGI enabled. (PMT-4661)
* [-] When migrating from Plesk 12.0 and later, additional users not assigned to any subscription are now migrated. (PMT-4658)

# 2.17.7 (23 September 2019)

* [-] Migration now migrates the content of mailboxes to Plesk Obsidian for Linux. (PMT-4647)

# 2.17.6 (18 September 2019)

* [*] Security improvements.
* [-] Additional users with the rights to manage a single subscription but whose email address was created under a different subscription (for example, a user created under `example.com` with email `user@example.net`) are now migrated when the subscription they were created under is migrated. (PMT-4644)

# 2.17.5 (8 August 2019)

* [*] Adjusted Plesk Migrator to support the maximum length of FTP usernames in Plesk 17.8 and above (32 characters).

# 2.17.4 (17 July 2019)

* [-] When migrating to Plesk from the latest version of CPanel that has MySQL 5.7 installed, database users are now also migrated and the applications work correctly after the migration. (PMT-4627)

# 2.17.3 (1 July 2019)

* [-] Migration of domains that have mixed-case names to Plesk 17.8 for Linux no longer fails on the step of copying 
content. (PMT-4621)

# 2.17.2 (18 June 2019)

* [*] The extension is now compatible with Plesk Obsidian.
* [-] Databases can now be migrated to target Plesk servers on Windows in which the "Chinese (Simplified, China)" language is set as the system locale. (PMT-4570)

# 2.17.1 (30 August 2018)

* [-] Improved detection of SSL protocol to communicate between the source and target servers. (PMT-4528)
* [-] Email messages flags are now preserved when importing mail to the MailEnable Enterprise/Premium server. (PMT-4449)
* [-] Improved processing of IP addresses in DNS zones. (PMT-4461)

# 2.17.0 (3 July 2018)

* [-] Plesk Migrator no longer displays the issue and the details as two separate issues in pre-migration check report. (PMT-4452)
* [-] Plesk Migrator no longer migrates subscriptions' overuse policies incorrectly by setting them all to
"Overuse is allowed". (PMT-4375)
* [-] Plesk Migrator now shows a newly created customer, reseller, or hosting plan to which you can reassign the subscription during migration. (PMT-4284)
* [-] Plesk Migrator no longer recommends to install a dropped Apache Tomcat component when migrating from a source server with installed Apache Tomcat
to a destination server with Plesk 17.8.9 and later. (PMT-4217)
* [-] On Linux servers migration no longer fails to start if the source MySQL server has a customized `wait_timeout` parameter set to a
small value (for example 15 seconds). (PMT-4395)
* [-] On Windows servers migration no longer fails if the `cp65001` encoding is used on the source server. (PMT-4439)
* [-] On Windows servers Plesk Migrator no longer fails to migrate a customer whose name contains the slash character ("/"). (PMT-4430)
* [-] On Windows servers Plesk Migrator no longer fails to migrate MIME types from the source server with Helm. (PMT-4392)

# 2.16.1 (31 May 2018)

* [*] Minor internal security improvements.

# 2.16.0 (16 May 2018)

* [*] Improved the log viewer. 
* [-] Fixed the issue where all emails stored in any folders other than "Inbox" were not migrated to the target server
with installed SmarterMail 16.3. (PMT-4359)
* [-] Fixed the issue where the list of objects available for migration was empty when migrating from the cPanel source server where 
Apache config was stored in the `/etc/apache2` folder. (PMT-4351)
* [-] Fixed the issue where it was impossible to migrate from the Confixx, PPCPL, and cPanel source servers to Plesk 17.8 via the CLI because
the list of objects available for migration was not generated. (PMT-4332)
* [-] Fixed the issue where the Plesk interface showed that the pre-migration check is still in process while it was actually finished. (PMT-4281) 
* [-] On Linux servers fixed the issue where errors were not reported correctly when rsync failed to copy files on Linux. (PMT-4377)
* [-] On Linux servers fixed the issue where a subscription with configured additional Apache or nginx directives was migrated with the 
"Failed to transfer additional Apache/nginx directives" error. (PMT-4287)
* [-] On Windows servers fixed the issue where, during migration, emails were not copied if the target Plesk server had installed SmarterMail 16.3.6677. (PMT-4374) 
* [-] On Windows servers fixed the issue where the emails' flags were not preserved after migration to the target server with MailEnable 10: all emails 
were wrongly marked as "unread". (PMT-4372)
* [-] On Windows servers fixed the issue where, if several migrations (more than 10) were started simultaneously, the log viewer page started being 
constantly refreshed. (PMT-4268) 
* [-] On Windows servers fixed the issue where migration to Plesk from the source server with installed Smarter Mail 16 could hang up on the stage of copying mail content. (PMT-4201) 
* [-] On Windows servers fixed the issue where custom MIME types were not migrated correctly from the Plesk 8 and 9 source servers. (PMT-884)

# 2.15.0 (1 March 2018)

* [*] Created a separate extension for the website importing function, [Site Import](https://ext.plesk.com/packages/da879838-ad5e-46f3-8a2c-36d26adbd218-site-import).
* [*] Improved the generation of configuration files by adding multi-session support and implementing a number of other improvements.
* [*] Added the ability to increase the maximum length of the "restoration of hosting settings" stage (two hours by default) via the configuration file. The corresponding option and its description were added to the configuration file template.
* [*] Added the ability to skip individual migration steps via the configuration file.
* [-] Fixed the issue where the post-check report contained an error for every FTP user for which no password was specified in the hosting description file. (PMT-4072)
* [-] Fixed the issue where running post-migration checks after migrating a disabled subscription resulted in unnecessary errors being reported. (PMT-4106)
* [-] Fixed the issue where Plesk Migrator tried updating empty fields in the profiles of customers being migrated which could lead to increased migration times. (PMT-4261)
* [-] Fixed the issue where, during post-migration sync of multiple migrated subscriptions, the status of subscriptions for which all post-migration checks were finished was not being updated correctly and was displayed as "on hold" until the checks for all subscriptions were finished. (PMT-4265)
* [-] Fixed the issue where, when migrating from a Plesk for Linux server, manually added DKIM records were not migrated. (PMT-4086)
* [-] Fixed the issue where, when migrating a subscription with no hosting or with hosting set to "forwarding", the subscription's creation date was not migrated. (PMT-4051)
* [-] Fixed the issue where migrating a subscription with disabled ASP.NET resulted in errors during hosting settings restoration. (PMT-3420)
* [-] Fixed the issue where removing the extension left some extension's files on the file system. (PMT-4248)
* [-] Fixed the issue where the migration got stuck and was filling the migration log with errors if the connection to the source server was interrupted during the mail migration stage. (PMT-4169)

# 2.14.1 (14 February 2018)

* [-] Fixed the issue where, during update of a Plesk key, the error was written to the log file. (PMT-4282)

# 2.14.0 (26 December 2017)

* [+] Added the ability to connect to the source server via SSH and to use rsync for importing files.
* [*] Increased data transfer speed during website migration.
* [*] Added the ability to generate the configuration file for command line migration by running the `plesk-migrator configure` command.
* [*] On Windows servers added the ability to specify the path to the Microsoft SQL Server temporary directory by specifying the `remote-mssql-session-dir` option in the configuration file.
* [-] Fixed the issue where MySQL events and stored routines were not migrated. (PMT-4065)
* [-] Fixed the issue where migration failed if a user's password contained non-Unicode characters and the Enhanced security mode was disabled on the source server. (PMT-4103)
* [-] Fixed the issue where, if during a failed migration attempt a subscription's limits were not set correctly on the target server, Plesk Migrator did not try to update them during subsequent attempts. This could result in addon domains or subdomains belonging to the subscription not being migrated. (PMT-4066)
* [-] Fixed the issue where post-migration checks could sometimes stall when checking the migrated websites' pages. (PMT-4095)
* [-] Fixed the issue where website migration from servers with vsftpd installed was impossible if FTPS support was not configured for it. (PMT-4130)
* [-] Fixed the issue where Plesk Migrator occasionally failed when migrating multiple subscriptions to Plesk for Windows at once. (PMT-4170)
* [-] Fixed the issue where, if the document root directory contained there a directory with no "read" permissions, the path to the document root directory had to be specified manually. (PMT-4184)
* [-] Fixed the issue where, if the hosting description file was written in YAML, the number of domains to be migrated was very high, and multiple subscriptions were being migrated at once, migration could fail due to Plesk Migrator running out of memory. (PMT-4132)
* [-] On Linux servers fixed the issue where databases could not be migrated during website migration if the /var/www/ directory was mounted to a different partition on the target server. (PMT-4128)
* [-] On Linux servers fixed the issue where databases could not be migrated during website migration if on the target server a remote MySQL server was configured as the default database server. (PMT-4199)
* [-] On Windows servers fixed the issue where migrating content via rsync could be interrupted (for example, due to network connectivity issues or packet loss), which resulted in the migration stalling. (PMT-4163)
* [-] On Windows servers fixed the issue where files and folders with names containing national characters were not migrated during website migration. (PMT-3706)
* [-] On Windows servers fixed the issue where website migration could not start if a directory containing a symbolic link to itself was present on the source server. (PMT-4200)

# 2.12.0 (2 November 2017)

* [+] Now you can run pre-migration checks in the advanced migration mode. Successfully passing all checks automatically starts a migration.
* [*] Performance of scanning source server contents before importing sites has been drastically improved.
* [-] When preparing for a site import, one of the applications being unavailable resulted in failure to detect other applications and list them on the site import page. (PMT-4061)
* [-] When transferring a subscription from Plesk Onyx, only a single scheduled task was transferred to the target server. (PMT-3894)
* [-] When migrating a subscription from Plesk 11.5 or later, the password for site application database was not decrypted on the target server, which resulted in the application unable to work on the target server. (PMT-4026)
* [-] When migrating from a Linux server with Plesk Onyx, pre-migration checks did not detect it when the webmail, used on the source server, was missing on the target server. (PMT-3145)
* [-] A component, required by Plesk Migrator, was not bundled with it but instead downloaded before first site import. This could result in migration failure in case of network problems. Now the component is a part of Plesk Migrator and does not require separate downloading. (PMT-3735)
* [-] When migrating from Plesk servers, the APS applications were transferred only as content and not registered in Plesk. (PMT-4000)
* [-] The migration process was aborted if any customer's login name did not conform to the Plesk requirements (only alphanumeric characters and `-.'%_`). Now subscriptions owned by such customers are skipped during the migration. (PMT-3959)
* [-] Migration to a server with administrator's id different than the default one (`1`) resulted in failure to repeatedly migrate subscriptions or synchronize their content. (PMT-3078)
* [-] When migrating from Confixx, each transferred SSL certificate was installed as default certificate for all domains on the IP address, which resulted in all domains using the certificate of the latest migrated domain. (PMT-4043)
* [-] When migrating a subscription with a database and ODBC DSN (Data Source Name) from Plesk for Windows of version 12.5 or later, the DSN was not migrated. (PMT-3891)
* [-] Migration failed from a server having IP addresses with netmask set in short notation. (PMT-4048)
* [-] When migrating a subscription with `web.config` containing non-ASCII characters from a server with .NET 2.0 or 3.x to a server with only .NET 4.x, adjusting the `web.config` to the target server failed. (PMT-4029)

# 2.11.4 (20 September 2017)

* [+] Plesk Migrator now supports importing websites with Joomla, Drupal, and Prestashop installed (with certain limitations, to learn more, read Migration Guide for details).
* [+] Users can now view the migration log in real time and search the log for key phrases in the Plesk Migrator interface.
* [*] The reliability of migrations from servers with non-English locale has been improved.
* [-] Re-syncing a subscription that was reassigned to a different owner during migration flooded the migration log with PHP notices, and could corrupt the Plesk Migrator interface if the `display_errors` PHP option was enabled. (PMT-3887)
* [-] Migration from Plesk failed if one or more customer passwords on the source server decrypted to 'none'. (PMT-3876)
* [-] When migrating from Ubuntu or Debian to CentOS or RedHat Enterprise Linux (or vice versa), subscriptions with files owned by the web server that contained non-UTF-8 characters could be assigned to incorrect owners. (PMT-3860)
* [-] Migration could not be started if one or more secret keys in the Plesk database could not be decrypted correctly. (PMT-3298)
* [-] When migrating from Helm via the command line, the shallow-dump.xml file was created anew during each migration stage, which considerably prolonged the migration. (PMT-3921)
* [-] Migration from Helm failed if one or more packages had enabled features whose parent plan was deleted. (PMT-3912)
* [-] The post-migration report did not contain information about missing DNS records for domains whose names contained IDN characters. (PMT-3906)
* [-] Migration from Helm failed if one or more identical IP addresses were registered as both shared and dedicated on the source server. (PMT-3878)
* [-] Under specific circumstances, copying of mail content for individual mailboxes could fail. (PMT-3868)
* [-] Copying of mail content could fail when migrating MailEnable accounts with a large number of mails. (PMT-3866)
* [-] On servers with the Chinese locale, under specific circumstances, syncing Microsoft SQL Server databases could result in an error. (PMT-3832)
* [-] Migration from a server with Japanese locale could fail with a misleading error message when copying website content. (PMT-3705)
* [-] When importing an application to Plesk for Windows, the import could fail if the application had an exceedingly large number of files. (PMT-3975)
* [-] Plesk Migrator could not set the correct permissions for statistics and logs directories. (PMT-3934)
* [-] Migration from Plesk failed if MariaDB 10.0.32 or later was installed on the source server. (PMT-3916)
* [-] When migrating a subscription with Magento installed, the Magento configuration file was not updated if the Magento database was renamed during migration. (PMT-3513)
* [-] When migrating a subscription with Prestashop, the Prestashop configuration file was not updated if the Prestashop database was renamed during migration. (PMT-3520)
* [-] When importing an application, the contents of all application files were lost if the specified domain name belonged to a domain already hosted on the target server. (PMT-3967)

# 2.10.10 (20 July 2017)

* [+] A running site importing can now be stopped.
* [*] When importing directories, the path on the target server is shown on the import screen.
* [*] When migrating from Plesk versions 11.0 to 12.5, if a certain password can not be decrypted, migration does not stop, but a new random password is generated instead.
* [*] Sample configurations for migrating from and to Plesk servers with remote SmarterMail were added.
* [-] When migrating from Plesk 17.0 or later, encrypted passwords of additional FTP accounts were replaced with new random passwords. Now such passwords are migrated without changing. (PMT-3689)
* [-] If the target server's Plesk license did not include reseller accounts, migrating accounts with reseller privileges resulted in errors. Now Plesk Migrator handles such accounts in the following way:
      * all customer accounts, belonging to the reseller, become regular customer accounts;
      * all subscriptions, belonging to the reseller, are assigned to the administrator account;
      * the reseller account itself is not migrated.
  (PMT-3795)
* [-] Plesk Migrator failed to find the document root of an IDN subscription, which resulted in website import failing with an error. (PMT-3809)
* [-] Report about failure to transfer a file by FTP during site importing contained unnecessary information from program logs. Now only a short report is shown with a list of such files. (PMT-3713)
* [-] Java applications could not be migrated between Plesk servers. (PMT-3779)
* [-] A customized subscription expiration date was not migrated from Plesk 17.0 or later. (PMT-3843)
* [-] After consecutively running Switch DNS and Revert DNS on a migrated subscription, the subscription's checkbox on the advanced mode screen was still selected. (PMT-3835)
* [-] Migrating to Plesk Multi Server configured to use a non-standard SSH port resulted in failing to copy content with an 'Unable to connect' error. (PMT-3816)
* [-] The results of post-migration checks were always marked as 'Errors', even when all checks succeeded. (PMT-3820)
* [-] The websites' files with names, starting with a dot, were not imported. (PMT-3817)
* [-] If an attempt to perform DNS Switch with UI failed due to some problem, the following attempts resulted in errors even if the problem was resolved. (PMT-3845)
* [-] When migrating from DirectAdmin, some subscription limits could be migrated incorrectly. (PMT-3794)
* [-] When migrating to Plesk Multi Server, skipping pre-migration checks for a subscription resulted in failure to migrate such subscription. (PMT-3822)
* [-] When migrating websites from a Confixx server, the SSL certificates were transferred to the subscription's certificate pool and were not available for the subscription's domains. As a result, after any webserver reconfigration the websites became unable to use their certificates and had to use the default Plesk certificate. (PMT-3818)
* [-] If the source server was configured to produce any output in a non-interactive shell (such as an SSH welcome message), migration failed with an error. Now Plesk Migrator detects such configurations and shows a comprehensive message, explaining how to fix the issue. (PMT-3823)
* [-] When migrating from a server with Horde webmail to a server with different webmail, Plesk Migrator attempted to restore the mail address book, which resulted in an error. Now Plesk Migrator detects such situations and does not try to restore the address book. (PMT-3806)
* [-] On Windows servers, if the source system had services with names or descriptions, containing non-ASCII characters, the whole server migration failed with message 'Failed to remove missing Python and Perl scripting options from backup dump'. (PMT-3704)
* [-] If a subscription on Helm 3 server had a mail service enabled, but no mail IP available, migration of the subscription failed. (PMT-3856)
* [-] When migrating from Helm 3, subscriptions of customers with login name longer than 15 characters were skipped without notification. (PMT-3849)
* [-] On Windows servers migration GUI missed a link for downloading the RPC Agent installation package. (PMT-3829)
* [-] On Windows servers, under certain circumstances, dumping MySQL databases when migrating IDN subscriptions failed with 'Unicode Encode Error'. (PMT-3825)
* [-] Synchronizing or repeated migration of subscription's business objects (like databases, email accounts or domains) to a server with remote SmarterMail failed. (PMT-3819)
* [-] Restoring MS SQL databases on IDN subscriptions failed. (PMT-3840)
* [-] Subscriptions migration from Helm 3 servers failed, if the subscriptions were using web forwarding and had mailboxes and/or databases. (PMT-3859)
* [-] Migration from Windows 2003 x64 servers with non-English locale failed while copying files with message 'Failed to copy web files for subscription'. (PMT-3027)

# 2.9.2 (7 June 2017)

* [+] An option to migrate a reseller with all accounts and subscriptions has been implemented.
* [+] Now when a subscription, owner or subscription plan is already migrated, it can be hidden from the 'List of subscriptions' tab.
* [+] When migrating from cPanel, there is an option to choose whether to migrate subdomains and domain aliases as addon domains, thus preserving the related email accounts.
* [*] The DirectAdmin migration agent now checks the data consistency on the source side. It correctly performs migration even when there are errors in the configuration of some domains. The overall fault tolerance of the agent has been improved.
* [*] The 'List of subscriptions' tab was added to the migration screen. It replaces the 'Add subscriptions' tab in simple mode, or the 'Subscriptions list' tab in advanced mode.
* [-] When migrating sites from cPanel, the Plesk Migrator detected a single WordPress instance as two separate instances. (PMT-3672)
* [-] MySQL events were not transferred during migration. (PMT-3677)
* [-] In certain circumstances it was impossible to import a website, if its webspace had files with names, containing non-ASCII characters. (PMT-3703)
* [-] Now, if the target database has earlier version and does not support some features of the source database, a comprehensive message is shown at the end of migration. (PMT-3241)
* [-] MySQL databases could not be migrated if a database's admin password did not match the password stored in the PSA database. (PMT-3778)
* [-] Migration of mail content from cPanel failed, if the home directory on source was different from `/var/home/` (PMT-3212)
* [-] Several domain aliases, created by cPanel for internal purposes, were migrated as domain aliases in Plesk. Now Plesk Migrator recognizes and ignores such technical aliases. (PMT-3506)
* [-] Plesk Migrator did not set a password for the source server's user that it creates for copying content. Some servers' configurations forbid SSH authorization of such users, thus making copying unavailable. (PMT-3558)
* [-] Additional Apache and nginx directives of subscriptions were not transferred. (PMT-3072)

# 2.8.7 (24 May 2017)

* [+] When importing sites, databases, or directories, the actual status of each item is displayed. If import of an item failed or generated a warning, a detailed list of issues is available.
* [-] Removing an additional domain that was previously imported from another server resulted in an error in Plesk panel. (PMT-3701)
* [-] In case of a database name or database user name conflict during site import, if there were additional spaces between the names and values of corresponding variables in the `wp-config.php` file, the WordPress application did not work after import. (PMT-3673)
* [-] Passwords for accounts with names, containing Unicode characters outside of ASCII range, could not be decrypted after migration. (PMT-3667)
* [-] If the source FTP server did not support TLS, this negatively affected the performance during import site. (PMT-3643)
* [-] When migrating from Plesk Onyx, an error in decrypting a password for an account could result in resetting passwords for all accounts. (PMT-3604, PMT-3605)
* [-] Extension data on the target server could be overwritten by data from the source server. Now by default the server-wide extension settings are not migrated. (PMT-3586)
* [-] Overuse policy for reseller accounts was not migrated and instead was reset to 'Overuse of disk space and traffic is allowed'. (PMT-3469)
* [-] Database import failed if the PHP process had no write permission on the source server. (PMT-3682)
* [-] Copying a MySQL database from Plesk Onyx on a Linux server failed if the database server password was stored in plain text format. (PMT-3759)
* [-] Protected directories on subdomains were not migrated from DirectAdmin. (PMT-3764)
* [-] When using PureFTD on the source server, the site import performance was lower than expected. (PMT-3679)
* [-] Under certain circumstances, migration from a Plesk for Linux server could fail with an error message "Cause: 'int' object has no attribute 'isdigit'". (PMT-3621)
* [-] SSL Certificate Authority certificates were not migrated from DirectAdmin. (PMT-3613)
* [-] When migrating mail messages to Plesk for Linux via IMAP, if a mailbox name contained an uppercase character, the messages in it were not migrated. (PMT-3607)
* [-] When migrating from DirectAdmin, a cron task with a certain syntax could not be parsed. (PMT-3544)
* [-] When migrating from DirectAdmin, if a mailbox had an automatic reply set up, but the corresponding template file did not exist, the migration could not be performed. (PMT-3542)
* [-] When migrating from or to a Plesk server with a remote SmarterMail server: the type 'A' DNS records for mail (`mail.*`) were migrated incorrectly. (PMT-3725)
* [-] When migrating from Plesk with a remote SmarterMail server to Plesk with a local SmarterMail server, or vice versa, the webmail settings for hosting plans and subscriptions were not converted as intended. (PMT-3723)

# 2.7.9 (27 April 2017)

* [-] Site migration was blocked if the source web server rejected requests without the User-Agent header. (PMT-3698)
* [-] Subscriptions migration failed and the subscriptions were marked as migrated with errors during migration from Plesk for Windows 8.6, 9.5 or 10.4. (PMT-3702)

# 2.7.7 (20 April 2017)

* [-] When migrating to a Plesk server using a non-English locale, a confusing error message was displayed if the name of one or more files or directories on the source server contained national characters. (PMT-3294)
* [-] The lack of notifications or a progress bar during post-migration checks could confuse the user. (PMT-3309)
* [-] Migration could fail if multiple perl versions were installed on the source server and the PATH environment variable pointed at a custom perl version. (PMT-3376)
* [-] Web content was not copied if SSH access to the source server was limited to specific users and the users 'plesk-migrator*' were not allowed access. (PMT-3385)
* [-] PostgreSQL databases could not be migrated if PostgreSQL server version 9.5 or later was installed on the source server. (PMT-3391)
* [-] Under specific circumstances, the "Failed to remove temporary user" error was displayed during migration even if the temporary user was removed. (PMT-3399)
* [-] Entries in the subscription log were not sorted by date. (PMT-3525)
* [-] Microsoft SQL Server databases could not be migrated if the Microsoft SQL Server instance on the source server was configured to use a nonstandard port. (PMT-3547)
* [-] The header on the migration screen was corrupted if the Plesk interface language was set to Italian. (PMT-3548)
* [-] When migrating from DirectAdmin, quota for mailboxes was set to 100 MB even if it was set to unlimited on the source server. (PMT-3550)
* [-] Trying to re-sync business objects after deleting a mail account on the source server produced a confusing error message. (PMT-3552)
* [-] During site migration, WordPress sites using a remote database were not re-configured to use the database migrated to the destination server's MySQL server. (PMT-3562)
* [-] Removing the session folder created after initiating a site migration resulted in empty session folder and configuration file getting created. (PMT-3579)
* [-] If during migration names of some databases and database users were changed, after upgrading Plesk Migrator to the latest version and restarting the migration, the name changes were not preserved. (PMT-3582)
* [-] When migrating from DirectAdmin, if a mailbox and a forwarder with the same name were present on the source server, only the forwarder was migrated. (PMT-3585)
* [-] When migrating from Plesk Onyx, extension files stored in the "/usr/local/psa/var/modules/" directory were assigned incorrect ownership. (PMT-3587)
* [-] Migration from DirectAdmin failed if a DNS zone contained a white space character as a separator. (PMT-3600)
* [-] When migrating from Plesk, the "Restrict the ability to follow symbolic links" hosting plan setting was disabled on destination server even if it was enabled on the source. (PMT-3602)
* [-] Migration from DirectAdmin failed if a protected directory created in DirectAdmin was not physically present on the file system. (PMT-3618)
* [-] Migration from DirectAdmin failed if one or more mail users on the source server did not have a home directory configured. (PMT-3645)
* [-] Migration to Plesk Onyx could fail if one or more customers on the source server had unicode characters in their name. (PMT-3646)

# 2.6.11 (29 March 2017)

* [-] Migration of folders from a web site failed if an FTP server on the source server returned relative paths in the list of the folders. (PMT-3563)
* [-] The list of folders for migration could not be obtained by Plesk Migrator if "." or ".." were present in the folders list returned by the FTP server. (PMT-3569)
* [-] Migration of a web site content failed if the FTP connection was unexpectedly closed on copying the content. (PMT-3567)
* [-] Migration of a web site content failed after upgrading Plesk Migrator from version 2.1 or earlier to a later version. (PMT-3568)
* [-] The database of an imported WordPress site could not be migrated if the time of files migration exceeded the IDLE timeout of the source FTP server. (PMT-3575)
* [-] A WordPress site could not be migrated if redirection was enabled on the source domain. (PMT-3571)
* [-] Website migration could be blocked if the session folder was deleted after the migration. (PMT-3576)
* [-] Website migration failed with an uninformative error message if the document root could not be detected automatically. (PMT-3574)
* [-] The migration progress dialog got stuck if an error occurred while retrieving data from the source server. (PMT-3573)

# 2.6.3 (23 March 2017)

* [+] Migration of files, databases, and WordPress sites from any server available via FTP is now supported. 
* [-] Database content could not be synchronized in Plesk for Windows when different remote Microsoft SQL servers were used by the source and the target servers. (PMT-3509)
* [-] A database was duplicated during second migration of a subscription having capital characters in name. (PMT-3535)
* [-] During migration from DirectAdmin, content of administrator's subscription became unavailable if the owner of the document root folder was incorrect. (PMT-3508)
* [-] Migration from DirectAdmin could not be started if a customer with non-unicode symbols in the name was present on the source server. (PMT-3540)
* [-] Migration from DirectAdmin could not be started if a mail auto-reply had been created for a domain on the source server and then the file with the auto-reply message had been deleted. (PMT-3542)
* [-] Migration from DirectAdmin was blocked if a cron task on the source server could not be parsed. (PMT-3544)
* [-] After migration from a custom panel, the Apache error log file could not be opened in the Log Browser because of incorrect permissions. (PMT-3460)
* [-] MySQL server databases could not be migrated from DirectAdmin if a remote MySQL server was used on the source server. (PMT-3545)

# 2.5.4 (2 March 2017)

* [+] Migration from DirectAdmin 1.51 is now supported.
* [*] Migrated databases are automatically renamed before restoration to avoid conflicts in cases of the same names of databases and database users.
* [*] Administrator can now configure the depth of checked web site links in post-migration checks.
* [-] Migration from Plesk 11.0 failed when a custom button with an icon in PNG format was configured on the source server. (PMT-3458)
* [-] Migration on Windows could not start if the path to the 'plesk' utility was not specified in the PATH variable of the target server. (PMT-3452)
* [-] Migration on Windows could not start if no PHP handlers were installed on the target server. (PMT-3472)
* [-] MySQL databases could not be migrated if an incorrect or empty password was set in the MySQL configuration file. (PMT-3394)
* [-] Adjusting application settings could work infinitely in case when the parent folder of a web site on the source server contained symbolic links. (PMT-3412)
* [-] If an additional domain's IP address differed from the subscription's IP address, the DNS records of the additional domain could not be migrated. (PMT-3445)

# 2.4.9 (20 January 2017)

* [+] During migration of mail content from a custom panel, it is now possible to define configuration settings like for a subscription content. In particular, it is possible to specify files or directories that should be excluded from copying or to define advanced file mapping.
* [+] Plesk Migrator on Windows can now be configured to detect the scriptiong settings (PHP version, ASP.NET version, ASP) of a subscription on the source server and migrate them properly.
* [-] A subscription belonging to a reseller could not be synchronized with an add-on service plan after migration. (PMT-3413)
* [-] Post-migration checks did not detect error messages or warnings on a web page in case when the HTTP code and the title of the web page were identical on the source server and on the target server. (PMT-3388)
* [-] During migration from a custom panel, post-migration checks were run for an enabled subscription with disabled main domain. As a result, error messages were reported. Now no post-migration checks are run in this case. (PMT-3378)
* [-] During migration from a custom panel, post-migration checks failed if a subscription had an add-on domain with an IP address other than the subscription’s IP address. (PMT-3371)
* [-] Post-migration checks did not detect some typical PHP error messages or warnings on web pages. (PMT-3389)
* [-] Migration could not be started on CentOs 5. (PMT-3417)
* [-] An unclear error message was displayed during migration if the configuration files of migrated applications contained non-unicode symbols. As a result, the adjusting of all other applications of the migrated subscription failed. (PMT-3398)
* [-] An unclear error message was displayed during migration if WordPress configuration files contained non-UTF-8 symbols. As a result, the adjusting of a particular WordPress instance failed. (PMT-3400)
* [-] Migration from a custom panel failed if the hosting description contained binary data in password fields of hosting description. (PMT-3390)
* [-] If the web.config file of a web site contained XML namespaces, the web site could stop functioning after migration. (PMT-3387)
* [-] Migration could fail if many (more than 10000) application files were changed during adjusting. (PMT-3409)
* [-] After migration from a custom panel there were no write permissions in the document root of a migrated subscription, it these permissions were not set explicitly in the hosting description. Due to this issue, the permissions settings sometimes were lost during migration from Plesk Onyx to Plesk Onyx. (PMT-3407)
* [-] Web Presence Builder was not registered in Plesk after migration to Plesk for Windows 12.5 or Onyx. (PMT-3369)
* [-] Some errors related to Microsoft SQL Server were not reported in Plesk Migrator log. (PMT-3362)
* [-] If migration of a Microsoft SQL Server database failed, Plesk Migrator added a database dump to an existing dump file during each new attempt to migrate, thus increasing the size of the dump file. (PMT-3411)

# 2.3.2 (22 December 2016)

* [+] A new mode was added to migration from Confixx so that mail users will be able to log in to their mail accounts on the target server with their original usernames and passwords.
* [+] During migration from cPanel, it is now possible to change the document root of a migrated domain.
* [+] It is now possible to migrate mail content to/from Plesk Onyx using a remote SmarterMail server.
* [-] Domain alias could not be migrated if its name was present in the DNS template. (PMT-3340)
* [-] During migration, long FTP user names (with 16 or more symbols) were truncated to 15 symbols. Now the maximum length for FTP names is 16 symbols that corresponds to the limitation of Plesk. (PMT-3320)
* [-] An error occured during adjusting application files after migration if the file names contained non-ASCII symbols. (PMT-3334)
* [-] The description of copy content options in Plesk Migrator user interface was insufficient. (PMT-3330)
* [-] Migration of additional users associated with a subscription was performed incorrectly. As a result, the corresponding subscription could fail to migrate.(PMT-3351)
* [-] Web content could not be migrated from cPanel, Confixx, or Parallels Pro Control Panel for Linux, if CageFS was enabled on the source or target server. (PMT-3333)
* [-] Mail users having the permission to log in to Plesk on the source server could not log in to Plesk on the target server after migration. (PMT-3354)
* [-] Mail flags and folders were lost during migration from hMailServer 3. (PMT-2943)
* [-] Migration to/from Plesk failed if the Plesk database had a name other than ‘psa’. (PMT-3329)
