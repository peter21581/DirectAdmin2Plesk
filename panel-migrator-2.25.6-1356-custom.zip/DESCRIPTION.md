The new and improved Plesk Migrator user interface covers features previously available in CLI (Command Line Interface) only, giving your migrations **heightened stability** and **improved performance**. Gain control by seeing exactly what is migrated and what stage it's at. No need to call command line utilities to perform migrations. Enjoy a **more granular process**, with different phases per subscription, completely for free!

 - Ability to run various operations within migration of a subscription: pre-check (software compatibility), post-migration check (validates that major services of subscription are up and running on destination after migration completed), **subscription data synchronization**, objects synchronization (in case some changed on source server while migration in progress).
 - **Detailed queue status** for subscriptions selected for migration, showing operation in-progress for all selected subscriptions.
 - Variety of cool new features: **subscriptions mapping** to other client / reseller / plan / IP on destination server before migration started.
 - "Finish migration feature" - gracefully end migration of all subscriptions that started being migrated.
 - Simple mode: lets to do bulk migration of many subscription at once.
 - Advanced mode: lets you customize the process for each subscription.
