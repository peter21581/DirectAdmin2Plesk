
function formatDateFromTimestamp(timestamp)
{
    var date = new Date();
    date.setTime(timestamp * 1000);

    var year = date.getFullYear();
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var month = months[date.getMonth()];
    var day = date.getDate();
    var hour = padZero(date.getHours());
    var min = padZero(date.getMinutes());
    var sec = padZero(date.getSeconds());

    return day + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
}

function padZero(value)
{
    if (value < 10) {
        return "0" + value;
    } else {
        return value;
    }
}