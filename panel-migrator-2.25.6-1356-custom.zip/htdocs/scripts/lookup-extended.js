// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

// Extension over lookup control, with ability to enable and disable it
Jsw.LookUpExtended = Class.create(Jsw.LookUp, {
    'disable': function() {
        this._inputField.disable();
        this._inputField.stopObserving('focus');
        this._inputField.stopObserving('paste');
        this._inputField.stopObserving('blur');
        this._inputField.stopObserving('keyup');
        this._inputField.stopObserving('keydown');
        this._lookUpButton.stopObserving('click');
    },
    'enable': function() {
        this._inputField.enable();
        this._addEvents(function() {});
    }
});