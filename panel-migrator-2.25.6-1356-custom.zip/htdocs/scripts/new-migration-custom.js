// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

Jsw.onReady(function() {
    var form = $('new-migration-form');
    var hostingDescriptionFileRow = $('sourceServer-sourceHostingDescriptionFile-form-row');

    function panelTypeChanged() {
        var sourcePanel = $$('input:checked[type=radio][name="sourceServer[sourcePanelType]"]').first().value;

        if (sourcePanel == 'custom') {
            hostingDescriptionFileRow.show();
        } else {
            hostingDescriptionFileRow.hide();
        }
    }

    panelTypeChanged();

    $$('input[name="sourceServer[sourcePanelType]"]').each(function(elem) {
        elem.observe('change', panelTypeChanged);
    });
});