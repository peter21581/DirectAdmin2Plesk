
function configureFormSubmitPopup() {
    // Hack to make popup after form is submitted and processed at controller side:
    // redefine _onSuccess function, which will display popup and call the original _onSuccess
    // function.
    var formComponent = Jsw.getComponent('select-objects-to-migrate-form');
    var oldFunction = formComponent._onSuccess;
    formComponent._onSuccess = function(req) {
        var response = req.responseText.evalJSON();
        var result = oldFunction.apply(this, arguments);
        var taskId = response.task;
        if (taskId) {
            // If pre-migration checks were started - show popup with progress
            showPreChecksPopup(taskId, true, false);
        }
        return result;
    }
}

// Configure handling of "Show existing subscriptions" checkbox for all modes of selection (by subscription,
// by customer, by reseller, by plan)
function configureToggleExistingSubscriptions() {
    var showExistingSubscriptionElement = $('show-existing-subscriptions');

    function toggleExistingSubscriptions() {
        var listComponentIds = [
            'subscriptionList',
            'customerList',
            'resellerList',
            'planList'
        ];
        listComponentIds.forEach(function (listComponentId) {
            var listComponent = Jsw.getComponent(listComponentId);

            if (showExistingSubscriptionElement.checked) {
                listComponent.filterItems(null);
            } else {
                listComponent.filterItems(function (item) {
                    return !item.alreadyExists;
                });
            }
        });
    }

    toggleExistingSubscriptions();
    showExistingSubscriptionElement.observe('click', toggleExistingSubscriptions);
}