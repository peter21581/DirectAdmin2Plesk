// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

// Show popup dialog with service node and IP address type selection for Plesk Multi Server.
// Arguments: subscriptions - list of subscription names.
function showSelectNodePopup(subscriptions, onSuccess) {
    // compose title - it is different when one subscription is selected
    // and when multiple subscriptions are selected
    var title = '';
    if (subscriptions.length > 1) {
        title = migratorLocale.lmsg('popupSelectNodeTitleMultiple', { count: subscriptions.length } );
    } else if (subscriptions.length == 1) {
        title = migratorLocale.lmsg('popupSelectNodeTitleSingle', { subscriptionName: subscriptions[0] });
    } else {
        // no subscriptions - no sense to show dialog
        return;
    }

    new Ajax.Request(URL_LIST_PLESK_MULTI_SERVER_NODES, {
        onSuccess: function (response) {
            var nodeIPs = response.responseText.evalJSON();

            var popupContent = '<div class="form-box">' +
                 '<div class="form-row">' +
                    '<div class="field-name">' + migratorLocale.lmsg('popupSelectNodeNode') + '</div>' +
                    '<div class="field-value">' +
                        '<div id="select-node-input-container"></div>' +
                    '</div>' +
                 '</div>' +
                 '<div class="form-row">' +
                    '<div class="field-name">' + migratorLocale.lmsg('popupSelectNodeIPv4Type') + '</div>' +
                    '<div class="field-value">' +
                        '<div class="text-value">' +
                            '<div class="indent-box">' +
                                '<input type="radio" name="mappingTypeV4" id="mappingTypeV4Shared" class="radio" value="shared" checked="checked"> ' +
                                '<label for="mappingTypeV4Shared">' +
                                    migratorLocale.lmsg('popupSelectNodeIPShared') +
                                '</label>' +
                            '</div>' +
                            '<div class="indent-box">' +
                                '<input type="radio" name="mappingTypeV4" id="mappingTypeV4Dedicated" class="radio" value="dedicated"> ' +
                                '<label for="mappingTypeV4Dedicated">' +
                                    migratorLocale.lmsg('popupSelectNodeIPDedicated') +
                                '</label>' +
                            '</div>' +
                            '<div class="indent-box">' +
                                '<input type="radio" name="mappingTypeV4" class="radio" id="mappingTypeV4None" value="none"> ' +
                                '<label for="mappingTypeV4None">' +
                                    migratorLocale.lmsg('popupSelectNodeIPNone') +
                                '</label>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="form-row">' +
                    '<div class="field-name">' + migratorLocale.lmsg('popupSelectNodeIPv6Type') + '</div>' +
                    '<div class="field-value">' +
                        '<div class="text-value">' +
                            '<div class="indent-box">' +
                                '<input type="radio" name="mappingTypeV6" id="mappingTypeV6Shared" class="radio" value="shared"> ' +
                                '<label for="mappingTypeV6Shared">' +
                                    migratorLocale.lmsg('popupSelectNodeIPShared') +
                                '</label>' +
                            '</div>' +
                            '<div class="indent-box">' +
                                '<input type="radio" name="mappingTypeV6" id="mappingTypeV6Dedicated" class="radio" value="dedicated"> ' +
                                '<label for="mappingTypeV6Dedicated">' +
                                    migratorLocale.lmsg('popupSelectNodeIPDedicated') +
                                '</label>' +
                            '</div>' +
                            '<div class="indent-box">' +
                                '<input type="radio" name="mappingTypeV6" class="radio" id="mappingTypeV6None" value="none" checked="checked"> ' +
                                '<label for="mappingTypeV6None">' +
                                    migratorLocale.lmsg('popupSelectNodeIPNone') +
                                '</label>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
            '</div>';

            var popup = new Jsw.Popup({
                title: title,
                content: popupContent,
                buttons: [
                    {
                        id: 'selectNodeOkButton',
                        title: migratorLocale.lmsg('popupSelectNodeButtonOk'),
                        class: 'action',
                        handler: function (event, popup) {
                            disableButtonInProgress($('selectNodeOkButton'), 'changingButtonTitle');
                            disableButtonPlain($('selectNodeCancelButton'));

                            var parameters = {
                                subscriptions: Object.toJSON(subscriptions),
                                ipv4: $$('input:checked[type=radio][name=mappingTypeV4]').first().value,
                                ipv6: $$('input:checked[type=radio][name=mappingTypeV6]').first().value,
                                nodeIP: $$('input[name=select-node]').first().value
                            };

                            new Ajax.Request(URL_CHANGE_IP_SUBSCRIPTIONS, {
                                parameters: parameters,
                                onSuccess: function (response) {
                                    if (onSuccess) {
                                        onSuccess();
                                    }
                                    popup.hide();
                                }
                            });
                        }
                    },
                    {
                        id: 'selectNodeCancelButton',
                        title: migratorLocale.lmsg('popupSelectNodeButtonCancel'),
                        handler: function (event, popup) {
                            popup.hide();
                        }
                    }
                ],
                popupCls: 'popup-panel popup-panel-centered migrator-popup-reassign'
            });

            popup.show();

            function addLookup(nodeIPAddresses)
            {
                var nodeIPLookupData = [];
                for (var i = 0; i < nodeIPAddresses.length; i++) {
                    var ip = nodeIPAddresses[i];
                    nodeIPLookupData.push({id: ip, title: ip});
                }

                var lookup = new Jsw.LookUpExtended({
                    id: 'select-node',
                    name: 'select-node',
                    renderTo: 'select-node-input-container',
                    data: nodeIPLookupData,
                    value: '',
                    locale: SELECT_NODE_LOCALE
                });
            }

            addLookup(nodeIPs);
        }
    });
}