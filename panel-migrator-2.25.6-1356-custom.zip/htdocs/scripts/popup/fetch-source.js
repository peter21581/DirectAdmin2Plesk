// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

function showFetchSourcePopup(session, onFinishedSuccess, onCloseWithErrors) {
    var errorMessage = null;
    var errorId = null;
    var cancel = false;

    var popup = new Jsw.Popup({
        title: 'Preparing migration',
        content: (
            '<div style="margin-bottom: 10px;">' +
                '<div id="fetch-source-action-text">' +
                    migratorLocale.lmsg('fetchSourceStarting') +
                '</div>' +
                '<div id="fetch-source-error-text" style="display: none">' +
                '</div>' +
                '<div id="fetch-source-download-rpc-agent" style="margin-top: 15px; display: none;">' +
                    '<a href="' + URL_DOWNLOAD_RPC_AGENT + '">' +
                        migratorLocale.lmsg('downloadRpcAgent') +
                    '</a>' +
                '</div>' +
            '</div>' +
            '<div class="migrator-progress-bar" id="fetch-source-progress-bar">' +
                '<div class="migrator-progress-bar-wrap">' +
                    '<div style="width: 100%;" class="migrator-progress-bar-fill"><span></span></div>' +
                '</div>' +
            '</div>'
        ),
        buttons: [
            {
                id: 'fetch-source-cancel-button',
                title: migratorLocale.lmsg('fetchSourceButtonCancel'),
                handler: function (event, popup) {
                    cancel = true;

                    elemActionText.show();
                    elemErrorText.hide();
                    elemErrorDownloadRpcAgent.hide();
                    elemProgressBar.show();
                    elemCancelButton.show();
                    elemCloseButton.hide();
                    elemActionText.update(migratorLocale.lmsg('fetchSourceCancelling'));

                    new Ajax.Request(URL_CANCEL_FETCH_SOURCE + '/session/' + session);
                }
            },
            {
                id: 'fetch-source-close-button',
                title: migratorLocale.lmsg('fetchSourceButtonClose'),
                handler: function (event, popup) {
                    popup.hide();
                    if (errorMessage && onCloseWithErrors) {
                        onCloseWithErrors(errorId, errorMessage);
                    }
                }
            }
        ],
        popupCls: 'popup-panel popup-panel-centered'
    });

    popup.show();

    var elemActionText = $('fetch-source-action-text');
    var elemErrorText = $('fetch-source-error-text');
    var elemErrorDownloadRpcAgent = $('fetch-source-download-rpc-agent');
    var elemProgressBar = $('fetch-source-progress-bar');
    var elemCancelButton = $('fetch-source-cancel-button').up();
    var elemCloseButton = $('fetch-source-close-button').up();

    elemCloseButton.hide();

    function pollProgress() {
        new Ajax.Request(URL_GET_PROGRESS + '/session/' + session, {
            onSuccess: function (response) {
                var progress = response.responseText.evalJSON();

                if (
                    progress.status == overallStatus.FINISHED_OK ||
                    progress.status == overallStatus.FINISHED_WARNINGS
                ) {
                    if (cancel) {
                        cancel = false;
                        popup.hide();
                        return;
                    }
                    // Show that operation has finished and redirect to object selections screen
                    elemActionText.show();
                    elemErrorText.hide();
                    elemErrorDownloadRpcAgent.hide();
                    elemProgressBar.hide();
                    elemActionText.update(migratorLocale.lmsg('fetchSourceFinished'));

                    if (onFinishedSuccess) {
                        onFinishedSuccess();
                    }
                } else if (
                    progress.status == overallStatus.FINISHED_ERRORS
                ) {
                    if (cancel) {
                        cancel = false;
                        popup.hide();
                        return;
                    }

                    // Show error message
                    elemActionText.hide();
                    elemErrorText.show();
                    if (progress.errorId && progress.errorId.indexOf('RPC_AGENT_') === 0) {
                        elemErrorDownloadRpcAgent.show();
                    } else {
                        elemErrorDownloadRpcAgent.hide();
                    }
                    elemProgressBar.hide();
                    elemCancelButton.hide();
                    elemCloseButton.show();
                    elemErrorText.update(formatStr(progress.errorMessage));
                    // Set error variables so they could be passed back to display error handler
                    errorMessage = progress.errorMessage;
                    errorId = progress.errorId;
                } else { // Not started or in progress
                    // Update progress message if exists

                    if (!cancel) {
                        elemActionText.show();
                        elemErrorText.hide();
                        elemErrorDownloadRpcAgent.hide();
                        elemProgressBar.show();
                        elemCancelButton.show();
                        elemCloseButton.hide();

                        if (progress.action) {
                            elemActionText.update(formatStr(progress.action));
                        }
                    }

                    // Poll progress once more
                    setTimeout(pollProgress, FETCH_SOURCE_POLL_INTERVAL);
                }
            },
            onFailure: function() {
                setTimeout(pollProgress, FETCH_SOURCE_POLL_INTERVAL);
            }
        });
    }

    pollProgress();
}