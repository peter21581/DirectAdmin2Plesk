// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

// Show popup dialog with migration issues for some object
// Arguments:
// - title: popup dialog title
// - issues - array of objects, each object describes an issue and contains problem text, solution text, etc,
//   see asDictionary method of Modules_PanelMigrator_Backend_Issue
function showIssuesPopupDialog(title, issues) {
    var popupContent = '';

    popupContent += '<div class="status-details-dialog-content">';

    function composeIssueHtml(issue) {
        var image = migratorImage('subscription-status-success.png');
        if (issue.severity == issueSeverity.ERROR) {
            image = migratorImage('subscription-status-error.png');
        } else if (issue.severity == issueSeverity.WARNING) {
            image = migratorImage('subscription-status-warning.png');
        }

        var html = '';
        html += '<div>';
        html += '<img src="' + image + '" class="status-details-dialog-issue-icon">';
        html += '&nbsp;';
        html += formatStr(issue.problemText);

        if (issue.solutionText) {
            html += '<br/>';
            html += formatStr(issue.solutionText);
        }
        html += '</div>';

        return html;
    }

    if (issues.length > 0) {
        // Step #1: Group issues by date and operation
        var groupedIssues = {};

        issues.each(function(issue) {
            var date = issue.executionDate;
            var operation = issue.executionCommandTitle;

            if (!groupedIssues[date]) {
                groupedIssues[date] = {};
            }
            if (!groupedIssues[date][operation]) {
                groupedIssues[date][operation] = [];
            }
            groupedIssues[date][operation].push(issue);
        });

        // Step #2: Order issue dates for further iteration
        var executionDates = Object.keys(groupedIssues);
        executionDates.sort();
        executionDates.reverse();

        // Step #3: Iterate over dates, operations and issues, composing the popup contents
        executionDates.forEach(function(date) {
            var operations = Object.keys(groupedIssues[date]);
            operations.forEach(function(operation) {
                var issuesOfDateAndOperation = groupedIssues[date][operation];

                popupContent += (
                    '<h4>[' + formatDateFromTimestamp(date) + '] ' + operation + '</h4><hr/>'
                );

                issuesOfDateAndOperation.each(function(issue) {
                    popupContent += composeIssueHtml(issue);

                    if (
                        // not the last issue in the dialog, to avoid duplication of <hr/> which is
                        // displayed by popup itself
                        !(
                            date == executionDates[executionDates.length - 1] &&
                            operation == operations[operations.length - 1] &&
                            issue == issuesOfDateAndOperation[issuesOfDateAndOperation.length - 1]
                        )
                    ) {
                        popupContent += '<hr/>';
                    }
                });
            });
        });
    } else {
        popupContent += migratorLocale.lmsg('popupStatusDetailsNoIssues');
    }

    popupContent += '</div>';

    var popup = new Jsw.Popup({
        title: title,
        content: popupContent,
        buttons: [
            {
                title: migratorLocale.lmsg('popupStatusDetailsButtonOk'),
                class: 'action',
                handler: function(event, popup) {
                    popup.hide();
                }
            }
        ],
        popupCls: 'popup-panel popup-panel-xl popup-panel-centered'
    });

    popup.show();
}
