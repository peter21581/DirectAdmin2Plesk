// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

Jsw.onReady(function() {
    var radioSSHAuthPassword = $('sourceServer-sourceSSHAuthType-password');
    var radioSSHAuthKey = $('sourceServer-sourceSSHAuthType-key');

    function updateSSHAuthType()
    {
        if (radioSSHAuthPassword.checked) {
            $('sourceServer-sourceSSHPassword-form-row').show();
            $('sourceServer-sourceSSHKeyPath-form-row').hide();
        } else {
            $('sourceServer-sourceSSHPassword-form-row').hide();
            $('sourceServer-sourceSSHKeyPath-form-row').show();
        }
    }

    radioSSHAuthPassword.observe('change', updateSSHAuthType);
    radioSSHAuthKey.observe('change', updateSSHAuthType);

    updateSSHAuthType();
});