Jsw.onReady(function() {
    $$('.migrate-by-mode-selector-radio input').invoke('observe', 'change', function(e) {
        $$('.migrate-by-mode-selector-radio').invoke('removeClassName', 'checked');
        e.target.up('.migrate-by-mode-selector-radio').addClassName('checked');
    });

    var modes = ['subscription', 'customer', 'reseller', 'plan'];

    function toggleModeRows()
    {
        for (var i = 0; i < modes.length; i++)
        {
            var mode = modes[i];
            if ($('mode-' + mode).checked) {
                $(mode + 'List-form-row').show();
            } else {
                $(mode + 'List-form-row').hide();
            }
        }

        if ($('mode-subscription').checked) {
            $('reassignOwner-form-row').show();
        } else {
            $('reassignOwner-form-row').hide();
        }
    }

    for (var i = 0; i < modes.length; i++)
    {
        var mode = modes[i];
        $('mode-' + mode).observe('change', toggleModeRows);
    }

    toggleModeRows();
});