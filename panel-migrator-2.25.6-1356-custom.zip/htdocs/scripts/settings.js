// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

Jsw.onReady(function() {
    var postChecksEnabledCheckbox = $('postChecksSettings-performPostMigrationChecks');

    function updatePostCheckControls() {
        var controls = [
            $('postChecksSettings-externalDns'),
            $('postChecksSettings-mailMessagesDeltaLimit'),
            $('postChecksSettings-websiteAvailabilityCheckTimeout')
        ];
        for (var i = 0; i < controls.length; i++) {
            if (postChecksEnabledCheckbox.checked) {
                controls[i].enable();
            } else {
                controls[i].disable();
            }
        }
    }

    postChecksEnabledCheckbox.observe('change', function() {
        updatePostCheckControls();
    });

    updatePostCheckControls();
});