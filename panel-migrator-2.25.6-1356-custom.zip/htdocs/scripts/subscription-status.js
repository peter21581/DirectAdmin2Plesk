// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

var subscriptionStatus = {
    NOT_STARTED: 'not-started',
    REVERTED: 'reverted',
    FINISHED_OK: 'finished-ok',
    FINISHED_WARNINGS: 'finished-warnings',
    FINISHED_ERRORS: 'finished-errors',
    QUEUED: 'on-hold',
    CANCELLED: 'cancelled',
    IN_PROGRESS: 'in-progress'
};

var subscriptionStatuses = [];

subscriptionStatuses.push({
    'name': subscriptionStatus.QUEUED,
    'titleSubscriptionsList': 'subscriptionsListStatusQueued',
    'imageSubscriptionsList': null,
    'showDetailsAction': true
});
subscriptionStatuses.push({
    'name': subscriptionStatus.CANCELLED,
    'titleSubscriptionsList': 'subscriptionsListStatusCancelled',
    'imageSubscriptionsList': null,
    'showDetailsAction': true
});
subscriptionStatuses.push({
    'name': subscriptionStatus.IN_PROGRESS,
    'titleSubscriptionsList': 'subscriptionsListStatusInProgress',
    'imageSubscriptionsList': migratorImage('subscription-status-in-progress.gif'),
    'showDetailsAction': true
});
subscriptionStatuses.push({
    'name': subscriptionStatus.NOT_STARTED,
    'titleSubscriptionsList': 'subscriptionsListStatusNotStarted',
    'imageSubscriptionsList': null,
    'showDetailsAction': false
});
subscriptionStatuses.push({
    'name': subscriptionStatus.FINISHED_OK,
    'titleSubscriptionsList': 'subscriptionsListStatusFinishedOk',
    'imageSubscriptionsList': migratorImage('subscription-status-success.png'),
    'showDetailsAction': true
});
subscriptionStatuses.push({
    'name': subscriptionStatus.FINISHED_WARNINGS,
    'titleSubscriptionsList': 'subscriptionsListStatusFinishedWarnings',
    'imageSubscriptionsList': migratorImage('subscription-status-warning.png'),
    'showDetailsAction': true
});
subscriptionStatuses.push({
    'name': subscriptionStatus.FINISHED_ERRORS,
    'titleSubscriptionsList': 'subscriptionsListStatusFinishedErrors',
    'imageSubscriptionsList': migratorImage('subscription-status-error.png'),
    'showDetailsAction': true
});

var subscriptionStatusOperation = {
    MIGRATION: 'migrated',
    CONTENT_SYNC: 'content-synced',
    DNS_SWITCH: 'dns-switched',
    POST_MIGRATION_CHECKS: 'post-migration-checks'
};

var subscriptionStatusOperations = [];

subscriptionStatusOperations.push({
    name: subscriptionStatusOperation.MIGRATION,
    titleSubscriptionsList: 'subscriptionsListOperationMigration',
    displayAlways: true
});

subscriptionStatusOperations.push({
    name: subscriptionStatusOperation.CONTENT_SYNC,
    titleSubscriptionsList: 'subscriptionsListOperationContentSync',
    displayAlways: false
});

subscriptionStatusOperations.push({
    name: subscriptionStatusOperation.DNS_SWITCH,
    titleSubscriptionsList: 'subscriptionsListOperationDnsSwitch',
    displayAlways: false
});

subscriptionStatusOperations.push({
    name: subscriptionStatusOperation.POST_MIGRATION_CHECKS,
    titleSubscriptionsList: 'subscriptionsListOperationPostMigrationCheck',
    displayAlways: false
});
