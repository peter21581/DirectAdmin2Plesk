// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

Jsw.onReady(function() {
    // Start queue runner periodically in case in terminated for some reason, so
    // even if it failed or there is race condition - customer will get migration
    // running again by just visiting migration status page
    function periodicRunQueue() {
        new Ajax.Request(URL_RUN_QUEUE, {
            onComplete: function (response) {
                setTimeout(
                    function () { periodicRunQueue() },
                    RUN_QUEUE_PERIOD
                );
            }
        })
    }

    periodicRunQueue();
});