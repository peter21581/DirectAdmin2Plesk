// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

Jsw.MigratorDoubleListSelector = Class.create(Jsw.EnhancedDoubleListSelector, {
    // overridden to have description of element under title, as we have in non-enhanced double list selector
    // that is necessary to show subscriptions that already exist on the target host (were already migrated before)
    _getItemText: function($super, element, highlight) {
        var result = $super(element, highlight);
        if (element.description) {
            result += '<div style="color: grey;">' + element.description + '</div>';
        }
        return result;
    },

    filterItems: function(filterFunction) {
        this._filterFunction = filterFunction;

        var searchElement = $(this._id + '-search-unselected');
        this.onToggleSearch('unselected', searchElement.value);
    },

    // overridden for ability to hide/show already migrated subscriptions (customers/resellers/plans with
    // all migrated subscriptions)
    onToggleSearch: function(columnId, searchString) {
        searchString = searchString.strip().toLowerCase();

        if (searchString.length) {
            this._toggleSearchButtonIcon(columnId, true);
            this._showSearchItems(columnId, searchString);
        } else {
            this._toggleSearchButtonIcon(columnId, false);
            this._showAllItems(columnId);
        }
    },

    _showSearchItems: function(columnId, searchString) {
        var isSelected = (columnId === 'selected');
        var self = this;

        this._list.each(function(element, index) {
            var item = $(this._id + '-' + index + '-' + columnId + '-item');
            if (
                this._isSearchMatched(element, searchString) &&
                // overridden here: check if we want to show that element
                (
                    isSelected || // always show items from the right column
                    !self._filterFunction || // filter function not set - show all items
                    self._filterFunction(element) // filter function is set - check if we should show the element
                )
            ) {
                item.down('.edls-text').update(this._getItemText(element, searchString));
                if (isSelected === element.selected) {
                    item.show();
                }
            } else {
                item.down('.edls-text').update(this._getItemText(element));
                var checkbox = item.down('.edls-check input');
                if (item.visible() && checkbox.checked) {
                    this._toggleItemCheckbox(checkbox, false);
                }
                item.hide();
            }
        }, this);
    },

    // overridden for ability to hide/show already migrated subscriptions (customers/resellers/plans with
    // all migrated subscriptions)
    _showAllItems: function(columnId) {
        var isSelected = (columnId === 'selected');
        var self = this;
        this._list.each(function(element, index) {
            var item = $(this._id + '-' + index + '-' + columnId + '-item');
            item.down('.edls-text').update(this._getItemText(element));
            if (
                isSelected === element.selected &&
                // overridden here: check if we want to show that element
                (
                    isSelected || // always show items from the right column
                    !self._filterFunction || // filter function not set - show all items
                    self._filterFunction(element) // filter function is set - check if we should show the element
                )
            ) {
                item.show();
            } else {
                item.hide();
            }
        }, this);
    }
});