// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

var overallStatus = {
    NOT_STARTED: 'not-started',
    FINISHED_OK: 'finished-ok',
    FINISHED_WARNINGS: 'finished-warnings',
    FINISHED_ERRORS: 'finished-errors',
    IN_PROGRESS: 'in-progress'
};