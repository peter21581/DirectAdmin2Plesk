// Copyright 1999-2017. Plesk International GmbH. All Rights Reserved.

Jsw.onReady(function() {
    var radioRemoteSmarterMailAutomaticDeploy = $(
        'remoteSmarterMailServer-targetRemoteSmarterMailRPCAgentDeployMode-automatic'
    );
    var radioRemoteSmarterMailManualDeploy = $(
        'remoteSmarterMailServer-targetRemoteSmarterMailRPCAgentDeployMode-manual'
    );

    function updateRemoteSmarterMailRPCAgentDeployType()
    {
        if (radioRemoteSmarterMailAutomaticDeploy.checked) {
            $('remoteSmarterMailServer-targetRemoteSmarterMailWindowsLogin-form-row').show();
            $('remoteSmarterMailServer-targetRemoteSmarterMailWindowsPassword-form-row').show();
            $('remoteSmarterMailServer-rpcAgentDownload-form-row').hide();
        } else {
            $('remoteSmarterMailServer-targetRemoteSmarterMailWindowsLogin-form-row').hide();
            $('remoteSmarterMailServer-targetRemoteSmarterMailWindowsPassword-form-row').hide();
            $('remoteSmarterMailServer-rpcAgentDownload-form-row').show();
        }
    }

    radioRemoteSmarterMailAutomaticDeploy.observe('change', updateRemoteSmarterMailRPCAgentDeployType);
    radioRemoteSmarterMailManualDeploy.observe('change', updateRemoteSmarterMailRPCAgentDeployType);

    updateRemoteSmarterMailRPCAgentDeployType();
});