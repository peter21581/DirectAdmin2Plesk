HD=$(dirname "$0")/hosting-description.yaml
echo "customers:" > $HD
echo "  -" >> $HD
echo "    login: jsmith" >> $HD
echo "    password: 123qwe" >> $HD
echo "    contact_info:" >> $HD
echo "       name: John Smith" >> $HD
echo "       email: jsmith@example.com" >> $HD
echo "    subscriptions:" >> $HD
echo "      -" >> $HD
echo "        name: example.com" >> $HD
echo "        sys_user:" >> $HD
echo "          login: jsmith" >> $HD
echo "          password: 123qwe1" >> $HD
if [ ! -d "$(dirname "$0")/output" ]; then
  mkdir $(dirname "$0")/output
fi
echo "done" > $(dirname "$0")/output/log.txt