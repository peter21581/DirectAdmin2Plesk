import yaml
import os

if __name__ == '__main__':
    data = {
        'customers': [
            {
                'login': 'jsmith',
                'password': '123qwe',
                'contact_info': {
                    'name': 'John Smith',
                    'email': 'jsmith@example.com'
                },
                'subscriptions': [
                    {
                        'name': 'example.com',
                        'sys_user': {
                            'login': 'jsmith',
                            'password': '123qwe1'
                        }
                    }
                ]
            }
        ]
    }
    script_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(script_dir, 'hosting-description.yaml'), 'w') as f:
        yaml.safe_dump(data, f, encoding='utf-8', allow_unicode=True)
    output_dir = os.path.join(script_dir, 'output')
    if not os.path.isdir(output_dir):
        os.mkdir(output_dir)
    with open(os.path.join(script_dir, 'output', 'log.txt'), 'w') as f:
        f.write('done')
