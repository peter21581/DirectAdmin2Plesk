from parallels.core.connections.server import Server


class TargetServer(Server):
    """Base interface to interact with target server and get various common information about it.
    """

    def description(self):
        """Return brief server description which should help end customer
        to identify server and which should be used in all messages

        :rtype: str | unicode
        """
        raise NotImplementedError()

    def ip(self):
        """Return main IP address of the server

        :rtype: str | unicode
        """
        raise NotImplementedError()

    def is_local(self):
        raise NotImplementedError()

    @property
    def python_bin(self):
        if self.is_windows():
            # Not implemented for target server, consider it has no Python. Implement in child classes
            # if you need to use Python there.
            return None
        else:
            # use default OS Python
            return 'python'

    def get_path_to_mysql(self):
        """Get path to mysql.exe on that source server

        :rtype: str
        """
        return 'mysql'

    def __hash__(self):
        """Implement for using nodes as dictionary keys, for the purpose of grouping"""
        raise NotImplementedError()

    def __eq__(self, another):
        """Implement for using nodes as dictionary keys, for the purpose of grouping"""
        raise NotImplementedError()
