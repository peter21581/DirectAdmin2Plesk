

class BackupProgress(object):
    """Class to track progress of mail messages backup"""

    STEP_DETECT_IMAP_HOST = 'detect-imap-host'
    STEP_CONNECT = 'connect'
    STEP_LOGIN = 'login'
    STEP_DETECT_FOLDER_SEPARATOR = 'detect-folder-separator'
    STEP_TRANSFER_MESSAGES = 'transfer-messages'

    ERROR_CONNECT = 'connect'
    ERROR_SECURITY = 'security'
    ERROR_SECURITY_INVALID_CERTIFICATE = 'security-invalid-certificate'
    ERROR_AUTHENTICATION = 'authentication'
    ERROR_IMAP_HOST_AUTODETECT = 'imap-host-autodetect'

    def set_step(self, step):
        """Set step of backup, which is currently executing (see STEP_* constants)

        :type step: str | unicode
        :rtype: None
        """
        raise NotImplementedError()

    def set_error(self, error_id, error_message):
        """Set error which occurred during backup

        Use ERROR_* constants for error ID, and comprehensive human-readable error message.

        :type error_id: str | unicode
        :type error_message: str | unicode
        :rtype: None
        """
        raise NotImplementedError()

    def set_imap_vendor(self, imap_vendor):
        """Set IMAP vendor name in backup progress

        :type imap_vendor: str | unicode
        :rtype: None
        """
        raise NotImplementedError()

    def set_imap_host_detection_method(self, method):
        """Set identifier of a method which actually detected IMAP host

        Check plesk_mail_migrator.providers.imap.server_detect.detect for more details.

        :type method: str | unicode
        :rtype: None
        """
        raise NotImplementedError()

    def set_autodetected_imap_host(self, imap_host):
        """Set hostname of automatically detected IMAP host

        Check plesk_mail_migrator.providers.imap.server_detect.detect for more details.

        :type imap_host: str | unicode
        :rtype: None
        """
        raise NotImplementedError()
