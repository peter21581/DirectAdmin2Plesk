
class Config(object):
    """Configuration for the web stream downloader"""
    def __init__(
        self,
        password=None, local_path=None, remote_path=None, excludes=None, stream_url=None,
        ssl_verify_certificates=None, ssl_ca_bundle=None
    ):
        """Class constructor

        :type password: str | unicode | None
        :type local_path: str | unicode | None
        :type remote_path: str | unicode | None
        :type excludes: list[str | unicode] | None
        :type stream_url: str | unicode | None
        :type ssl_verify_certificates: bool | None
        :type ssl_ca_bundle: str | unicode | None
        """
        self._password = password
        self._local_path = local_path
        self._remote_path = remote_path
        self._excludes = excludes
        self._stream_url = stream_url
        self._ssl_verify_certificates = ssl_verify_certificates
        self._ssl_ca_bundle = ssl_ca_bundle

    @property
    def password(self):
        """Web rpc agent`s authentication password

        :rtype: str | unicode | None
        """
        return self._password

    @property
    def local_path(self):
        """Where to copy on local server

        The path is a binary string in UTF-8 encoding.

        :rtype: str | None
        """
        return self._local_path

    @property
    def remote_path(self):
        """Where to copy from remote server

        The path is a binary string in UTF-8 encoding.

        :rtype: str | None
        """
        return self._remote_path

    @property
    def excludes(self):
        """
        :rtype: list[str | unicode] | None
        """
        return self._excludes

    @property
    def stream_url(self):
        """

        :rtype: str | None
        """
        return self._stream_url

    @property
    def ssl_verify_certificates(self):
        """
        :rtype: bool | None
        """
        return self._ssl_verify_certificates

    @property
    def ssl_ca_bundle(self):
        """
        :rtype: str | unicode | None
        """
        return self._ssl_ca_bundle

    @property
    def list_empty_properties(self):
        """List of non-filled properties

        :rtype: list
        """
        list_empty = []
        if self._password is None:
            list_empty.append('password')
        if self._local_path is None:
            list_empty.append('local_path')
        if self._remote_path is None:
            list_empty.append('remote_path')
        if self._stream_url is None:
            list_empty.append('stream_url')
        return list_empty

    @property
    def ready_for_copy(self):
        """Returns 'True' if all properties are filled

        :rtype: bool
        """
        return len(self.list_empty_properties) == 0
