from plesk_mail_migrator.providers.imap.server_detect.methods.base import ImapServerDetectMethod


class DomainNameServerDetectMethod(ImapServerDetectMethod):
    """Simply use domain name as IMAP host"""

    def detect(self, domain_name):
        """Detect IMAP host(s) for specified domain name.

        For example, if you have e-mail "john@example.com", and you pass "example.com" to this function,
        it may detect and return two IMAP servers ["imap1.example.com", "imap2.example.com"]

        :type domain_name: str | unicode
        :rtype: list[str | unicode]
        """
        return [domain_name]

    def is_fast(self):
        """Whether the method is fast: fast methods do not perform requests to thirdparty services (DNS, HTTP)

        :rtype: bool
        """
        return True

    def get_method_id(self):
        """Get method ID to be used in command line, statistics, etc

        :rtype: str | unicode
        """
        return 'domain-name'
