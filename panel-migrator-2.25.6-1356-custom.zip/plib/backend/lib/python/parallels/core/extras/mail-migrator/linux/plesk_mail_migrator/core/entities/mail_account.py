
class MailAccount(object):
    def __init__(self, user_name, user_password, domain):
        self._user_name = user_name
        self._user_password = user_password
        self._domain = domain

    @property
    def user_name(self):
        return self._user_name

    @property
    def user_password(self):
        return self._user_password

    @property
    def domain(self):
        return self._domain
