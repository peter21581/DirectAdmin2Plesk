
class DumpReader(object):
    def read_message(self):
        raise NotImplementedError()
