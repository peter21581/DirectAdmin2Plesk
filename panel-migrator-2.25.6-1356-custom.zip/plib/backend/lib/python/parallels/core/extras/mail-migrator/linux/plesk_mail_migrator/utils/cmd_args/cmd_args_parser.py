from plesk_mail_migrator.utils.exceptions import MailMigratorException


class CmdArgsParser(object):
    def get(self, arg_name):
        """Get value of string command-line argument

        :type arg_name: str | unicode
        :rtype: str | unicode | None
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        raise NotImplementedError()

    def getboolean(self, arg_name):
        """Get value of boolean command-line argument

        :type arg_name: str | unicode
        :rtype: bool
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        raise NotImplementedError()

    def getinteger(self, arg_name):
        """Get value of integer command-line argument

        :type arg_name: str | unicode
        :rtype: int
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        raise NotImplementedError()

    def getenum(self, arg_name, allowed_values):
        """Get value of enumerated (which has fixed set of valid values) command-line argument
        :type arg_name: str | unicode
        :type allowed_values: list[str | unicode]
        :rtype: str | unicode
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        raise NotImplementedError()

    def contains(self, arg_name):
        """
        :type arg_name: str | unicode
        :rtype: bool
        """
        raise NotImplementedError()

    def get_full_param_name(self, short_name):
        """
        :type short_name: str | unicode
        :rtype: str | unicode
        """
        raise NotImplementedError()


class CommandLineArgumentException(MailMigratorException):
    """Class for issues when specified command line arguments are not valid"""
    pass
