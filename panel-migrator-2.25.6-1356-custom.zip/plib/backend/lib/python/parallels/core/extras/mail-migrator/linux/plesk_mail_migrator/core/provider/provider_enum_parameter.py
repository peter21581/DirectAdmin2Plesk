from plesk_mail_migrator.core.provider.provider_parameter import ProviderParameter


class ProviderEnumParameter(ProviderParameter):
    def __init__(self, name, description, allowed_values, value=None, help_value=None):
        self._allowed_values = allowed_values
        super(ProviderEnumParameter, self).__init__(name, description, value, help_value)

    def parse(self, argparser):
        """
        :type argparser: plesk_mail_migrator.utils.cmd_args_parser.CmdArgsParser
        """
        if argparser.contains(self.name):
            self.value = argparser.getenum(self.name, self._allowed_values)
