from plesk_mail_migrator.core.progress.restore.restore_progress import RestoreProgress


class RestoreProgressEmpty(RestoreProgress):
    """Class to track progress of mail messages restoration - when we don't want the progress to be reported anywhere"""

    def set_restored_message(self, message_num):
        """Set that mail migrator restores specified message number right now

        :type message_num: int
        :rtype: None
        """
        pass

    def set_stat_restored_messages(self, message_num, overall_messages_length):
        """Sets appropriate field in restore progress required for stats

        :type message_num: int
        :type overall_messages_length: int
        :rtype: None
        """
        pass

