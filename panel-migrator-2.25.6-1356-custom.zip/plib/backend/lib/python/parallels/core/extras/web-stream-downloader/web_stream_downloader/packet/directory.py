
class PacketDirectory(object):
    def __init__(self, directory_path):
        self._directory_path = directory_path

    @property
    def directory_path(self):
        return self._directory_path