from plesk_mail_migrator.providers.imap.server_detect.methods.base import ImapServerDetectMethod
from plesk_mail_migrator.providers.imap.server_detect.utils import get_imap_servers_from_autodetect_url


class AutoconfigXmlDomainImapServerDetectMethod(ImapServerDetectMethod):
    """Detect IMAP host by XML located at https://autoconfig.<domain>/mail/config-v1.1.xml"""
    def __init__(self, ca_bundle):
        """
        :param str | unicode ca_bundle: Path to CA certificates bundle
        """
        self._ca_bundle = ca_bundle

    def detect(self, domain_name):
        """Detect IMAP host(s) for specified domain name.

        For example, if you have e-mail "john@example.com", and you pass "example.com" to this function,
        it may detect and return two IMAP servers ["imap1.example.com", "imap2.example.com"]

        :type domain_name: str | unicode
        :rtype: list[str | unicode]
        """
        return get_imap_servers_from_autodetect_url(
            'https://autoconfig.%s/mail/config-v1.1.xml' % domain_name, domain_name, self._ca_bundle
        )

    def is_fast(self):
        """Whether the method is fast: fast methods do not perform requests to thirdparty services (DNS, HTTP)

        :rtype: bool
        """
        return False

    def get_method_id(self):
        """Get method ID to be used in command line, statistics, etc

        :rtype: str | unicode
        """
        return 'autoconfig-xml-domain'
