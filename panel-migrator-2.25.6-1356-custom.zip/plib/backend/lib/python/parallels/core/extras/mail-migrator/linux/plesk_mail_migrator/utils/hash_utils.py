import hashlib


class HashUtils(object):
    @staticmethod
    def calculate_hash(data):
        """Calculate MD5 hash for provided byte string and return the hash as string

        :type data: str
        :rtype: str
        """
        m = hashlib.md5()
        m.update(data)
        return m.hexdigest()
