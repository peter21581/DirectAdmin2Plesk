LOG_EXCEPTION = "Exception: "
COMPLETELY_FAILED_TO_DOWNLOAD_DIRECTORY = (
    "Completely failed to download directory"
)
COMPLETELY_FAILED_TO_DOWNLOAD_DIRECTORY_DETAILS = (
    "Error message: {error_message}\n"
    "Source path: {source_path}\n"
    "Target path: {target_path}\n"
    "Web stream URL: {stream_url}\n"
)
RETRY_INITIAL = "Failed to download data, try once more. Reason: {reason}"
RETRY_SEVERAL_ATTEMPTS = (
    "Failed to download data after {attempts} attempts. Wait for {seconds} seconds and try once more. Reason: {reason}"
)
UNFINISHED_STREAM = "Unfinished stream"
DOWNLOADING_FROM = "Downloading data from {url}, POST data is '{data}'"
FINISHED = "Download finished"
INVALID_PACKET_TYPE = "Invalid packet type"
FAILED_TO_CREATE_DIRECTORY = "Failed to create directory '{directory}': {reason}"
FAILED_TO_WRITE_FILE = "Failed to write file '{filename}': {reason}"
