from plesk_mail_migrator.core.dumps.dump_reader import DumpReader


class QueueDumpReader(DumpReader):
    def __init__(self, queue):
        self._queue = queue

    def read_message(self):
        return self._queue.get(True)
