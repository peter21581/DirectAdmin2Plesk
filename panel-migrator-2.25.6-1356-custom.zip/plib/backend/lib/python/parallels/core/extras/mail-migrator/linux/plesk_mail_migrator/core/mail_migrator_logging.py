import logging


def init_logging():
    """Initialize logging (should be executed before any logging operation is performed).

    :rtype: None
    """
    logging.getLogger('plesk_mail_migrator').addHandler(_null_logging_handler)


def configure_logging(argparser):
    """Configure logger according to command-line arguments

    :type argparser: plesk_mail_migrator.utils.cmd_args_parser.CmdArgsParser
    :rtype: None
    """
    if argparser.contains('log-file'):
        logging.basicConfig(
            format="%(asctime)s,%(msecs)03d|%(levelname)s|%(message)s",
            datefmt='%Y-%m-%d_%H:%M:%S',
            filename=argparser.get('log-file'),
            level=logging.DEBUG
        )


def enable_console_logging():
    """Enable logging to console (STDOUT).

    By default it is disabled (no logging is performed or if log file option is specified then mail migrator
    writes log to the file)

    :rtype: None
    """
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    logging.getLogger('plesk_mail_migrator').removeHandler(_null_logging_handler)
    logging.getLogger('plesk_mail_migrator').addHandler(console_handler)
    logging.getLogger('plesk_mail_migrator').setLevel(logging.INFO)


_null_logging_handler = logging.NullHandler()
