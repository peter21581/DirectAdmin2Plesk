
class MailMessage(object):
    def __init__(self, message_id, folder, flags, body):
        self._message_id = message_id
        self._folder = folder
        self._flags = flags
        self._body = body

    @property
    def message_id(self):
        return self._message_id

    @property
    def folder(self):
        return self._folder

    @property
    def flags(self):
        return self._flags

    @property
    def body(self):
        return self._body
