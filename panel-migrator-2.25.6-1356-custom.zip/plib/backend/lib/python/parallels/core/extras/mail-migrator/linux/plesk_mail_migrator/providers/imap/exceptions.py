
class ImapAutodetectFailedException(Exception):
    """Error which states that automatic detection of IMAP hostname has failed, and you should specify it manually"""
    pass


class ImapOverSSLIssue(Exception):
    """Error which states that connection failed, but it is possible to try less secure ways to connect"""
    pass


class ImapOverSSLInvalidCertificateIssue(Exception):
    """Error which states that SSL certificate is invalid, but it is possible to try less secure ways to connect"""
    pass
