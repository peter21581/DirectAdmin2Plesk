from plesk_mail_migrator.core.provider.provider_parameter import ProviderParameter


class ProviderBooleanParameter(ProviderParameter):
    def parse(self, argparser):
        """
        :type argparser: plesk_mail_migrator.utils.cmd_args_parser.CmdArgsParser
        """
        if argparser.contains(self.name):
            self.value = argparser.getboolean(self.name)
