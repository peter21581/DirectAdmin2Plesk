from plesk_mail_migrator.core.provider.base_provider import BaseProvider


# noinspection PyAbstractClass
class BackupProvider(BaseProvider):
    def do_backup_messages(self, account, dumper, exclude_message_ids, backup_progress, stop_mark):
        """Dump (backup) messages of specified mail account

        :param plesk_mail_migrator.core.entities.mail_account.MailAccount account:
            Mail account for which we should dump messages
        :param plesk_mail_migrator.core.dumps.dump_writer.DumpWriter dumper:
            Object capable of writing dumps
        :param set[str] exclude_message_ids:
            Messages to exclude when dumping. Check "How the tool works with message IDs" in README for details
        :param plesk_mail_migrator.core.progress.backup.backup_progress.BackupProgress backup_progress:
            Object to report backup progress to
        :param plesk_mail_migrator.utils.stop_mark.StopMark stop_mark:
            Object which indicates if user has requested to stop backup/migration
        :rtype: list[str]
        """
        raise NotImplementedError()
