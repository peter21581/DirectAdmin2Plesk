

class MailMigratorException(Exception):
    """Base class for all mail migrator exceptions.

    Such exceptions will be displayed without "Internal error" prefix in user's messages.
    """
    pass
