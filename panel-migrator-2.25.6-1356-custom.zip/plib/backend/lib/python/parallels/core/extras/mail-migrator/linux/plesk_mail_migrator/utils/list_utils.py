
def get_last(l):
    """Get the last element of a list or a tuple.

    For example, for [1, 2, 3, 4] the function returns 4.

    :type l: list | tuple
    """
    return l[len(l) - 1]


def unique_list(lst):
    """Make list unique keeping order.

    For example, for list [1, 2, 3, 1, 1, 4, 3] the function returns [1, 2, 3, 4]

    :type lst: list | tuple
    :rtype: list
    """
    result = []
    for item in lst:
        if item not in result:
            result.append(item)
    return result
