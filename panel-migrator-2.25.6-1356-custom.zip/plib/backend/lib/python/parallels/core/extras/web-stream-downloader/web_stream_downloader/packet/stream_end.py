
class PacketStreamEnd(object):
    pass
