
class PacketFileEnd(object):
    pass
