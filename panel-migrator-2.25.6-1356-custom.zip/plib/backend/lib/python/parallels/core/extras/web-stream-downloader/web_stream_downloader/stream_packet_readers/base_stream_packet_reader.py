
class BaseStreamPacketReader(object):
    def __init__(self, fileobj):
        self._fileobj = fileobj

    def iter_packets(self):
        raise NotImplementedError()

    def _read_line(self):
        line = ''
        while True:
            c = self._fileobj.read(1)
            if c == '' or c == '\n':
                break
            line += c
        return line

    def _read_bytes(self, bytes):
        data = ''

        while True:
            c = self._fileobj.read(bytes - len(data))
            data += c

            if len(data) == bytes:
                break

            if c == '':
                raise Exception("Expected data")

        c = self._fileobj.read(1)

        if c != '\n':
            raise Exception("Expected newline")

        return data
