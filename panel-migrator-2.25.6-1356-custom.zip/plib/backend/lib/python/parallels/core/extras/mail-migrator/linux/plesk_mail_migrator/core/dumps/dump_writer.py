

class DumpWriter(object):
    def dump_from_contents(self, message_id, folder, flags, contents):
        """Add mail message to dump. We have message as a string

        :param str|None message_id: Message identifier.
            Check "How the tool works with message IDs" in README for details.
        :param str folder:
            IMAP folder of the message
        :param plesk_mail_migrator.core.entities.imap_flags.IMAPFlags flags:
            IMAP flags of the message
        :param str contents:
            String that contains the message
        :rtype: None
        """
        raise NotImplementedError()
