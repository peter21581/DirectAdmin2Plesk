import os


class StopMark(object):
    def __init__(self, filename):
        """
        :type filename: str | unicode
        """
        self._filename = filename

    def is_set(self):
        """
        :rtype: bool
        """
        if self._filename is None:
            return False
        else:
            return os.path.exists(self._filename)
