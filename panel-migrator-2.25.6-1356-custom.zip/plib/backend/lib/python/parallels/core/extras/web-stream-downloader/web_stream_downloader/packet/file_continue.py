
class PacketFileContinue(object):
    def __init__(self, start_position, file_path):
        self._start_position = start_position
        self._file_path = file_path

    @property
    def start_position(self):
        return self._start_position

    @property
    def file_path(self):
        return self._file_path
