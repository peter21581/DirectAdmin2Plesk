
class PacketType(object):
    DIRECTORY = 1
    FILE_START = 2
    FILE_CONTINUE = 3
    FILE_CHUNK = 4
    FILE_END = 5
    SYMLINK = 6
    ERROR = 7
    STREAM_END = 8
