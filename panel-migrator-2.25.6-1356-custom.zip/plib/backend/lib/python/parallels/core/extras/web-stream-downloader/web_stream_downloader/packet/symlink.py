
class PacketSymlink(object):
    def __init__(self, symlink_path, target):
        self._symlink_path = symlink_path
        self._target = target

    @property
    def symlink_path(self):
        return self._symlink_path

    @property
    def target(self):
        return self._target