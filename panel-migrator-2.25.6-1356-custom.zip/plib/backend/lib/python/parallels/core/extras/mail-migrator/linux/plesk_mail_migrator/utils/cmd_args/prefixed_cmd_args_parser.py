from plesk_mail_migrator.utils.cmd_args.cmd_args_parser import CmdArgsParser


class PrefixedCmdArgsParser(CmdArgsParser):
    """ Class to get prefixed command-line arguments.

    For example if prefix is set to "source", then for request of arguments "param"
    this class will return argument specified by "--source-param" command line option."""

    def __init__(self, cmd_args_parser, prefix):
        """Class constructor

        :type cmd_args_parser: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CmdArgsParser
        :type prefix: str
        """
        self._cmd_args_parser = cmd_args_parser
        self._prefix = prefix

    def get(self, arg_name):
        """Get value of string command-line argument

        :type arg_name: str | unicode
        :rtype: str | unicode | None
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        return self._cmd_args_parser.get('%s-%s' % (self._prefix, arg_name))

    def getboolean(self, arg_name):
        """Get value of boolean command-line argument

        :type arg_name: str | unicode
        :rtype: bool
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        return self._cmd_args_parser.getboolean('%s-%s' % (self._prefix, arg_name))

    def getinteger(self, arg_name):
        """Get value of integer command-line argument

        :type arg_name: str | unicode
        :rtype: int
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        return self._cmd_args_parser.getinteger('%s-%s' % (self._prefix, arg_name))

    def getenum(self, arg_name, allowed_values):
        """Get value of enumerated (which has fixed set of valid values) command-line argument

        :type arg_name: str | unicode
        :type allowed_values: list[str | unicode]
        :rtype: str | unicode
        :raises: plesk_mail_migrator.utils.cmd_args.cmd_args_parser.CommandLineArgumentException
        """
        return self._cmd_args_parser.getenum('%s-%s' % (self._prefix, arg_name), allowed_values)

    def contains(self, arg_name):
        """
        :type arg_name: str | unicode
        :rtype: bool
        """
        return self._cmd_args_parser.contains('%s-%s' % (self._prefix, arg_name))

    def get_full_param_name(self, short_name):
        """
        :type short_name: str | unicode
        :rtype: str | unicode
        """
        return "--%s-%s" % (self._prefix, short_name)
