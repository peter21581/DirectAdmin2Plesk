# coding=utf-8
"""
Messages overrides: language, common messages
"""
