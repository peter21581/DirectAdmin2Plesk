# coding=utf-8
"""
Messages overrides: language, specific to GUI
"""

from parallels.core.utils.message_utils import multi_line_message

UNABLE_LOGIN_S_SSH_SERVICE_DUE = multi_line_message(u"""
    Не удалось подсоединиться к %s по протоколу SSH: неправильные логин и/или пароль.
    Укажите правильные параметры доступа к серверу и нажмите "Далее".
""")
WINDOWS_AGENT_INSTALL_INSTRUCTIONS = multi_line_message(u"""
    Не удалось запустить RPC Agent на сервере '{source_ip}'.
    RPC Agent необходим для взаимодействия текущего сервера с сервером '{source_ip}'.

    В первую очередь, проверьте, что параметры доступа для Windows администратора заданы правильно.

    Если параметры доступа заданы верно, то, скорее всего, на удаленном сервере недоступен сервис File and Printer Sharing.
    В таком случае, автоматическая установка RPC Agent невозможна.

    Попробуйте загрузить установочный пакет приложения RPC Agent на сервер '{source_ip}' и запустить его вручную.
""")
