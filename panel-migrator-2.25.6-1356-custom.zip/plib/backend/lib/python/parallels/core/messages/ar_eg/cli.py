# coding=utf-8
"""
Messages overrides: language, specific to CLI
"""
