class ResellerPlanConverterAdapter(object):
    """Common interface for reseller plan converter adapter"""
    def convert(self, global_context, resellers_migration_list, report):
        """Convert reseller plans

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type resellers_migration_list: dict[str, str | None]
        :type report: parallels.core.reports.model.report.Report
        :rtype: list[parallels.core.target_data_model.ResellerPlan]
        """
        raise NotImplementedError()
