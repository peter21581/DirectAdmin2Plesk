
class LoggingProperties(object):
    """Properties describing how action should be logged"""
    def __init__(self, info_log=True, compound=True, top_level=False):
        self.info_log = info_log
        self.compound = compound
        self.top_level = top_level
