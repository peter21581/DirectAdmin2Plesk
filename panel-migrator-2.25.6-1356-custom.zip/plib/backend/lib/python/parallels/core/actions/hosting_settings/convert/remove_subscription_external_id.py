from parallels.core.logging import get_logger
from parallels.core import messages
from parallels.core.actions.base.subscription_backup_action import SubscriptionBackupAction
from parallels.core.actions.utils.logging_properties import LoggingProperties

logger = get_logger(__name__)


class RemoveSubscriptionExternalId(SubscriptionBackupAction):
    """Remove External ID for all subscriptions, so that they won't override
    ones assigned by default during hosting restoration process, to avoid special effects."""

    def get_description(self):
        return messages.REMOVE_EXTERNAL_IDS_FROM_BACKUP

    def get_failure_message(self, global_context, subscription):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        """
        return messages.FAILED_REMOVE_EXTERNAL_IDS_FOR_SUBSCRIPTION % subscription.name

    def get_logging_properties(self):
        return LoggingProperties(info_log=False)

    def _run_subscription_backup(
        self, global_context, subscription, subscription_backup
    ):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        """
        subscription_backup.delete_external_id()
