from parallels.core import messages
from parallels.core.actions.base.common_action import CommonAction


class ConvertClientsAndSubscriptionsAction(CommonAction):
    def get_description(self):
        """Get short description of action as string

        :rtype: str | unicode
        """
        return messages.ACTION_CONVERT_CLIENTS_AND_SUBSCRIPTIONS_DESCRIPTION

    def get_failure_message(self, global_context):
        """Get message for situation when action failed

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: str | unicode
        """
        return messages.ACTION_CONVERT_CLIENTS_AND_SUBSCRIPTIONS_FAILURE

    def run(self, global_context):
        """Run action

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: None
        """
        global_context.migrator._convert_model(global_context.convert_report, global_context.target_existing_objects)
