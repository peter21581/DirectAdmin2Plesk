import os

from parallels.core import MigrationNoContextError
from parallels.core import messages
from parallels.core.actions.base.common_action import CommonAction
from parallels.core.actions.migration_list.utils import get_migration_list_file_location
from parallels.core.logging import get_logger
from parallels.core.utils.common import get_executable_file_name, safe_format

logger = get_logger(__name__)


class CheckMigrationListExistsForMigration(CommonAction):
    def get_description(self):
        """
        :rtype: str | unicode
        """
        return messages.ACTION_CHECK_IF_MIGRATION_LIST_FILE_EXISTS_DESCRIPTION

    def get_failure_message(self, global_context):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: str | unicode
        """
        return messages.ACTION_CHECK_IF_MIGRATION_LIST_FILE_EXISTS_FAILURE

    def run(self, global_context):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: None
        """
        migration_list_file = get_migration_list_file_location(global_context)

        if not os.path.exists(migration_list_file):
            raise MigrationNoContextError(
                safe_format(
                    messages.MIGRATION_LIST_IS_NOT_DEFINED,
                    migration_list_file=migration_list_file,
                    migrator_executable=get_executable_file_name()
                )
            )
