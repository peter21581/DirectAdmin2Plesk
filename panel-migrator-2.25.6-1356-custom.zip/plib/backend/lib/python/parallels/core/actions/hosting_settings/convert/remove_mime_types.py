from parallels.core import messages
from parallels.core.actions.base.subscription_backup_action import SubscriptionBackupAction
from parallels.core.actions.utils.logging_properties \
    import LoggingProperties


class RemoveMimeTypes(SubscriptionBackupAction):
    """Remove MIME types for subscription in backup dump.

    MIME types are restored in a separate action (see TransferMIMETypes class),
    so we don't need them to be restored by PMM.
    Moreover, there are problems restoring MIME types with PMM for old versions of Plesk and other panels:
    default MIME types may be not restored, which makes site inoperable.
    """

    def get_description(self):
        """Get short description of action as string

        :rtype: str | unicode
        """
        return messages.ACTION_REMOVE_MIME_TYPES_FROM_BACKUP_DESCRIPTION

    def get_failure_message(self, global_context, subscription):
        """Get message for situation when action failed

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        :rtype: str | unicode
        """
        return messages.ACTION_REMOVE_MIME_TYPES_FROM_BACKUP_FAILURE

    def get_logging_properties(self):
        """Get how action should be logged to migration tools end-user

        :rtype: parallels.core.actions.utils.logging_properties.LoggingProperties
        """
        return LoggingProperties(info_log=False)

    def _run_subscription_backup(
        self, global_context, subscription, subscription_backup
    ):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        """
        subscription_backup.remove_mime_types()
