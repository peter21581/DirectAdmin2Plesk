from parallels.core import messages
from parallels.core.actions.base.common_action import CommonAction
from parallels.core.utils.config_creator import ConfigCreator
from parallels.core.logging import get_logger

logger = get_logger(__name__)

class CreateConfigFile(CommonAction):
    """Create config file (config.ini) by asking customer
    of required parameters in console interactively"""
    def get_description(self):
        """Get short description of action as string

        :rtype: str | unicode
        """
        return messages.ACTION_CREATE_CONFIG_FILE_DESCRIPTION

    def get_failure_message(self, global_context):
        """Get message for situation when action failed

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: str | unicode
        """
        return messages.ACTION_CREATE_CONFIG_FILE_FAILURE

    def run(self, global_context):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        """
        config = ConfigCreator()
        config.create(global_context)
