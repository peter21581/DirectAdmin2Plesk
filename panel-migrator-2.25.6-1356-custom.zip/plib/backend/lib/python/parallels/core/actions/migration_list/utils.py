def get_migration_list_file_location(global_context):
    """Get path of migration list file according to options specified by user

    :type global_context: parallels.core.global_context.GlobalMigrationContext
    """
    if hasattr(global_context.options, 'migration_list_file'):
        migration_list_file = global_context.options.migration_list_file
    else:
        migration_list_file = None

    if migration_list_file is None:
        return global_context.session_files.get_path_to_default_migration_list_file()
    else:
        return migration_list_file

