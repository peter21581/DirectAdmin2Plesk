from parallels.core import messages
from parallels.core.actions.base.common_action import CommonAction
from parallels.core.actions.utils.logging_properties import LoggingProperties


class RemoveContent(CommonAction):
    """Remove content XML nodes from backups created on PfW 8.6 to avoid issues when restoring dump

    PMM deployer may try to restore content nodes, while there is no actual content included in backup,
    so restore may fail. All content (mail messages, files, database tables, etc) is migrated by Plesk Migrator
    in separate actions, PMM deployer has nothing to do with content.
    """

    def __init__(self, subscription_backup):
        """Class constructor

        Arguments:
        - subscription_backup - object that can retrieve subscription backup
        object for each subscription, list of servers with backups

        :type subscription_backup: parallels.core.utils.backup_adapter.BackupAdapterBase
        """
        self._subscription_backup = subscription_backup

    def get_description(self):
        """Get short description of action as string

        :rtype: str | unicode
        """
        return messages.REMOVE_CONTENT_NODES_FROM_BACKUPS

    def get_failure_message(self, global_context):
        """Get message for situation when action failed

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: str | unicode
        """
        return messages.UNABLE_REMOVE_CONTENT_NODES_FROM_BACKUPS

    def get_logging_properties(self):
        """Get how action should be logged to migration tools end-user

        :rtype: parallels.core.actions.utils.logging_properties.LoggingProperties
        """
        return LoggingProperties(info_log=False)

    def run(self, global_context):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        """
        backup_ids = self._subscription_backup.get_backup_ids(global_context)

        for backup_id in backup_ids:
            backup = global_context.load_converted_dump(backup_id)

            if backup.is_windows:
                backup.remove_content()
