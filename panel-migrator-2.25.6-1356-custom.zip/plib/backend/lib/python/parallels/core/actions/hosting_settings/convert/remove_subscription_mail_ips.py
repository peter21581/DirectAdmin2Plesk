from parallels.core.logging import get_logger
from parallels.core import messages
from parallels.core.actions.base.subscription_backup_action import SubscriptionBackupAction
from parallels.core.actions.utils.logging_properties import LoggingProperties

logger = get_logger(__name__)


class RemoveSubscriptionMailIPs(SubscriptionBackupAction):
    """Remove mail IPs from backup dumps - they are useless or even harmful. Plesk will detect mail IPs itself."""

    def get_description(self):
        """Get short description of action as string

        :rtype: str | unicode
        """
        return messages.ACTION_REMOVE_MAIL_IPS_FROM_BACKUP_DESCRIPTION

    def get_failure_message(self, global_context, subscription):
        """Get message for situation when action failed

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        :rtype: str | unicode
        """
        return messages.ACTION_REMOVE_MAIL_IPS_FROM_BACKUP_FAILURE

    def get_logging_properties(self):
        """Get how action should be logged to migration tools end-user

        :rtype: parallels.core.actions.utils.logging_properties.LoggingProperties
        """
        return LoggingProperties(info_log=False)

    def _run_subscription_backup(
        self, global_context, subscription, subscription_backup
    ):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        """
        for domain in subscription_backup.iter_domains():
            for mail_object in [domain.mailsystem, domain.maillists]:
                if mail_object is not None:
                    mail_object.remove_ips()
