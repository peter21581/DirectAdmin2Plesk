from parallels.core.actions.base.base_action import BaseAction
from parallels.core.actions.utils.repeat_properties import RepeatProperties


class CommonAction(BaseAction):
    """Base class for migration process action

    Action is a single operation in migration process

    Examples of actions: copy web content, copy mail messages, fetch
    information from source panel, etc
    """

    def is_critical(self):
        """If action is critical or not

        If action is critical and it failed, migration tool completely stops.
        Otherwise it proceeds to the next steps of migrations.

        :rtype: bool
        """
        return True

    def get_failure_message(self, global_context):
        """Get message for situation when action failed

        This message should contain impact and ways to resolve or work the
        problem around

        Arguments:
        - global_context - registry with different objects that reused among different actions

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: str | unicode
        """
        raise NotImplementedError()

    def get_repeat_properties(self, global_context):
        """Get repeat properties - whether and how we should try to repeat action in case of a failure

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: parallels.core.actions.utils.repeat_properties.RepeatProperties
        """
        return RepeatProperties()

    def filter_action(self, global_context):
        """Check whether we should run this action or not. By default True - action should be executed.

        Arguments:
        - global_context - registry with different objects that reused among different actions

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: bool
        """
        return True

    def on_exception(self, global_context, exception):
        """Handle unhandled exceptions

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type exception: Exception
        :rtype: None
        """
        pass

    def run(self, global_context):
        """Run action

        Arguments:
        - global_context - registry with different objects that reused among different actions

        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :rtype: None
        """
        raise NotImplementedError()
