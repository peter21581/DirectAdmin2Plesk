
class ConditionActionPointer(object):
    """Dynamic pointer to an action that resolves into another action by condition
    """
    def resolve(self, global_context):
        """Resolve pointer to an action by condition that depends on global context"""
        raise NotImplementedError()
