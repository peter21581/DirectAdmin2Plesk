from parallels.core.utils.entity import Entity


class RepeatProperties(Entity):
    def __init__(self, repeat_count=1, repeat_timeout=30, repeat_message=None, success_message=None):
        self._repeat_count = repeat_count
        self._repeat_timeout = repeat_timeout
        self._repeat_message = repeat_message
        self._success_message = success_message

    @property
    def max_repeat_attempts(self):
        """Maximum number of repeat attempts

        :rtype: int
        """
        return self._repeat_count

    @property
    def repeat_interval(self):
        """Interval between repeat attempts in seconds

        :rtype: int
        """
        return self._repeat_timeout

    @property
    def repeat_message(self):
        """Message that will be displayed to log if we are going to repeat operation due to a failure

        :rtype: str | unicode | None
        """
        return self._repeat_message

    @property
    def success_message(self):
        """Message that will be displayed to log if action finished successfully after failed attempt

        :rtype: str | unicode | None
        """
        return self._success_message
