
def should_run_service_checks(global_context):
    """Check whether execution of service checks is enabled or disabled by CLI options

    :type global_context: parallels.core.global_context.GlobalMigrationContext
    :rtype: bool
    """
    return not (
        hasattr(global_context.options, 'skip_services_checks') and global_context.options.skip_services_checks
    )
