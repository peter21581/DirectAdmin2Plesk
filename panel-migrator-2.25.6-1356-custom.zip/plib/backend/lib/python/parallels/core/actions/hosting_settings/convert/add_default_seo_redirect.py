from parallels.core import messages
from parallels.core.actions.base.subscription_backup_action import SubscriptionBackupAction
from parallels.core.actions.utils.logging_properties import LoggingProperties


class AddDefaultSeoRedirect(SubscriptionBackupAction):
    """If domain or addon_domain have no option seoRedirect in dump, seoRedirect can
    be set according to Plesk global value. In result we could get different behavior
    of redirect on source and target server and errors on post-migration checks.
    Add seoRedirect=none if no such option in dump
    """

    def get_description(self):
        """Get short description of action as string

        :rtype: str
        """
        return messages.ACTION_ADD_SEO_REDIRECT_DESCRIPTION

    def get_failure_message(self, global_context, subscription):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        """
        return messages.ACTION_ADD_SEO_REDIRECT_FAILURE

    def is_critical(self):
        """If action is critical or not

        If action is critical and it failed for a subscription, migration tool
        won't run the next operations for the subscription.

        :rtype: bool
        """
        return False

    def get_logging_properties(self):
        """Get how action should be logged to migration tools end-user

        :rtype: parallels.core.actions.utils.logging_properties.LoggingProperties
        """
        return LoggingProperties(info_log=False)

    def _run_subscription_backup(
        self, global_context, subscription, subscription_backup
    ):
        """
        :type global_context: parallels.core.global_context.GlobalMigrationContext
        :type subscription: parallels.core.migrated_subscription.MigratedSubscription
        :type subscription_backup: parallels.core.dump.data_model.Subscription
        """
        subscription_backup.add_seo_redirect_if_not_set()
        for addon_domain in subscription_backup.iter_addon_domains():
            addon_domain.add_seo_redirect_if_not_set()
