
class OdbcDsn(object):
    def __init__(self, node):
        """
        :type node: xml.etree.ElementTree.Element
        """
        self._node = node

    @property
    def name(self):
        """
        :rtype: str | unicode | None
        """
        return self._node.attrib.get('name')

    @property
    def connection_string(self):
        """
        :rtype: str | unicode | None
        """
        return self._node.findtext('connection-string')

    @connection_string.setter
    def connection_string(self, value):
        """
        :type value: str | unicode
        """
        node = self._node.find('connection-string')
        if node is None:
            raise NotImplementedError()
        node.text = value
