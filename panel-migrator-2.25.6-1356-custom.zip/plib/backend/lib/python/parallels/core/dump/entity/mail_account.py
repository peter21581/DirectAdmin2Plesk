from parallels.core.dump.entity.password import get_password, set_password
from parallels.core.utils.common import parse_bool, is_not_none
from parallels.core.utils.common.xml import elem


class MailAccount(object):
    @classmethod
    def parse(cls, mail_user_node, domain_name):
        is_enable_cp_access = parse_bool(mail_user_node.attrib.get('cp-access-default'), False)

        mail_box_node = mail_user_node.find('preferences/mailbox')
        is_enable_mailbox = is_not_none(mail_box_node, lambda node: parse_bool(node.attrib.get('enabled'), False))

        aliases = []
        for alias_node in mail_user_node.findall('preferences/alias'):
            aliases.append(alias_node.text)

        is_enable_forwarding = parse_bool(mail_user_node.attrib.get('forwarding-enabled'), False)
        forwarding_addresses = []
        for forwarding_node in mail_user_node.findall('preferences/forwarding'):
            forwarding_addresses.append(forwarding_node.text)

        return MailAccount(
            node=mail_user_node,
            mail_user_name=mail_user_node.attrib['name'],
            domain_name=domain_name,
            is_enable_cp_access=is_enable_cp_access,
            is_enable_mailbox=is_enable_mailbox,
            aliases=aliases,
            is_enable_forwarding=is_enable_forwarding,
            forwarding_addresses=forwarding_addresses
        )

    def __init__(
        self, node, mail_user_name, domain_name, is_enable_cp_access, is_enable_mailbox, aliases,
        is_enable_forwarding, forwarding_addresses
    ):
        self._node = node
        self.mail_user_name = mail_user_name
        self.domain_name = domain_name
        self.is_enable_cp_access = is_enable_cp_access
        self.is_enable_mailbox = is_enable_mailbox
        self.aliases = aliases
        self.is_enable_forwarding = is_enable_forwarding
        self.forwarding_addresses = forwarding_addresses

    @property
    def name(self):
        return '%s@%s' % (self.mail_user_name, self.domain_name)

    @property
    def password(self):
        """
        :rtype: parallels.core.dump.entity.password.Password
        """
        return get_password(self._node.find('properties'))

    @password.setter
    def password(self, password):
        """
        :type password: parallels.core.dump.entity.password.Password
        """
        properties_node = self._node.find('properties')
        if properties_node is None:
            properties_node = elem('properties')
            self._node.insert(0, properties_node)
        set_password(properties_node, password)

    def remove_address_books(self):
        """Remove all address books with all contacts from XML

        :rtype: None 
        """
        preferences_node = self._node.find('preferences')
        if preferences_node is None:
            return
        address_book_node = preferences_node.find('addressbook')
        if address_book_node is None:
            return
        preferences_node.remove(address_book_node)
