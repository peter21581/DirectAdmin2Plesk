
class CommandTypes(object):
    MACRO = 'macro'
    MICRO = 'micro'
    INTERNAL = 'internal'


class CommandOperation(object):
    REGULAR = 'regular'
    TASK_MANAGER = 'task-manager'
    TASK_RUNNER = 'task-runner'


class Command(object):
    def __init__(
        self,
        name,
        type,
        help,
        method,
        parents=None,
        args=None,
        is_configuration_required=True,
        is_legacy=False,
        is_skip_progress_reporting=False,
        is_allow_parallel_execution=False,
        is_allow_stop=True,
        is_skip_logging=False,
        is_enable_profiling_by_default=True,
        command_operation=CommandOperation.REGULAR
    ):
        self.name = name
        self.type = type
        self.help = help
        self.method = method
        if parents is not None:
            self.parents = parents
        else:
            self.parents = []
        if args is not None:
            self.args = args
        else:
            self.args = []
        self.is_configuration_required = is_configuration_required
        self.is_legacy = is_legacy
        self.is_skip_progress_reporting = is_skip_progress_reporting
        self.is_skip_logging = is_skip_logging
        self.is_enable_profiling_by_default = is_enable_profiling_by_default
        self.is_allow_parallel_execution = is_allow_parallel_execution
        self.is_allow_stop = is_allow_stop
        self.command_operation = command_operation
