

class CLIExtensionBase(object):
    """Base class for extending CLI interface of migrator for different source and target panels"""
    def get_additional_commands(self, common_options):
        """
        :type common_options: parallels.core.cli.migration_cli.CommonMigrationOptions
        :rtype: list[parallels.core.cli.command.Command]
        """
        raise NotImplementedError()