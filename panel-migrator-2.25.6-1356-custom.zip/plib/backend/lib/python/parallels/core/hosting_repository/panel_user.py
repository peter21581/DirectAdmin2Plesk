class PanelUserModel(object):
    def create(self, user, owner):
        """Create user in target panel

        :type user: parallels.core.target_data_model.AuxiliaryUser
        :type owner: parallels.core.target_data_model.Client | parallels.core.target_data_model.Reseller
        """
        raise NotImplementedError()

    def is_exists(self, panel_user_username, owner_username):
        """Check if panel user with given username and owner exists in target panel

        :type panel_user_username: str
        :type owner_username: str
        :rtype: bool
        """
        raise NotImplementedError()
