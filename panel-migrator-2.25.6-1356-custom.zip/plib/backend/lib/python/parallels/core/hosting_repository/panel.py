from parallels.core.utils.entity import Entity


class PanelModel(object):
    def refresh_components(self):
        """Initiate update of cached data about installed target panel components; after that target panel should
        have an up-to-date info about installed components and ready to perform any capability checking
        """
        raise NotImplementedError()

    def is_service_plan_addon_available(self):
        """Return True in target panel is able to manipulate with service plan add-ons

        :rtype: bool
        """
        raise NotImplementedError()

    def get_administrator_guid(self, subscription_name):
        """Get GUID of administrator account for server with specified subscription

        :type subscription_name: str | unicode
        :rtype: str | unicode | None
        """
        raise NotImplementedError()

    def get_administrator_id(self, subscription_name):
        """Get ID of administrator account for server with specified subscription

        :type subscription_name: str | unicode | None
        :rtype: int
        """
        raise NotImplementedError()

    def get_installed_components(self, subscription_name):
        """Get list of installed components with their versions on the server with specified subscription

        :type subscription_name: str | unicode
        :rtype: dict[str | unicode, str | unicode]
        """
        raise NotImplementedError()

    def get_dns_template(self, subscription_name):
        """Get server-wide DNS template of the panel

        :type subscription_name: str | unicode
        :rtype: parallels.core.hosting_repository.panel.DNSTemplate
        """
        raise NotImplementedError()

    def get_available_webmails(self):
        """Get list of available webmail application IDs

        :rtype: list[str | unicode] | None
        """
        raise NotImplementedError()


class DNSTemplate(Entity):
    def __init__(self, dns_records):
        """
        :type dns_records: list[parallels.core.hosting_repository.panel.DNSTemplateRecord]
        """
        self._dns_records = dns_records

    @property
    def dns_records(self):
        """
        :rtype: list[parallels.core.hosting_repository.panel.DNSTemplateRecord]
        """
        return self._dns_records


class DNSTemplateRecord(Entity):
    def __init__(self, rec_type, src, dst, opt):
        """
        :type rec_type: str | unicode
        :type src: str | unicode
        :type dst: str | unicode
        :type opt: str | unicode
        """
        self._rec_type = rec_type
        self._src = src
        self._dst = dst
        self._opt = opt

    @property
    def rec_type(self):
        """
        :rtype: str | unicode
        """
        return self._rec_type

    @property
    def src(self):
        """
        :rtype: str | unicode
        """
        return self._src

    @property
    def dst(self):
        """
        :rtype: str | unicode
        """
        return self._dst

    @property
    def opt(self):
        """
        :rtype: str | unicode
        """
        return self._opt
