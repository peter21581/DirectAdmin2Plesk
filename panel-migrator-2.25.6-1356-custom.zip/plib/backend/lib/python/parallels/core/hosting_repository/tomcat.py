from parallels.core.utils.entity import Entity


class TomcatModel(object):
    def install_application(self, subscription_name, domain_name, application_war_file):
        """Install Java (Tomcat) application from specified WAR file

        :type subscription_name: str | unicode
        :type domain_name: str | unicode
        :type application_war_file: str | unicode
        :rtype: None
        """
        raise NotImplementedError()

    def list_applications(self, subscription_name, domain_name):
        """List Java (Tomcat) applications installed on specified domain
        
        :type subscription_name: str | unicode
        :type domain_name: str | unicode
        :rtype: list[parallels.core.hosting_repository.tomcat.TomcatApplicationEntity]
        """
        raise NotImplementedError()


class TomcatApplicationEntity(Entity):
    def __init__(self, domain_name, application_name):
        self._domain_name = domain_name
        self._application_name = application_name

    @property
    def domain_name(self):
        return self._domain_name

    @property
    def application_name(self):
        return self._application_name
