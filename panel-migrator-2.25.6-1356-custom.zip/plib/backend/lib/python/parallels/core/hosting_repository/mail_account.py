from parallels.core.utils.entity import Entity


class MailAccountModel(object):
    def create_from_dump(self, subscription_name, mail_account_dump):
        """Create mail account in target panel

        :type subscription_name: str | unicode
        :type mail_account_dump: parallels.core.dump.entity.mail_account.MailAccount
        """
        raise NotImplementedError()

    def create(self, mail_account, subscription_name):
        """Create mail account in target panel

        :type subscription_name: str | unicode
        :type mail_account: parallels.core.hosting_repository.mail_account.CreateMailAccountEntity
        """
        raise NotImplementedError()

    def enable_mailbox(self, subscription_name, mail_user_name, domain_name, password):
        """Enable mailbox for specified mail account

        :type subscription_name: str | unicode
        :type mail_user_name: str | unicode
        :type domain_name: str | unicode
        :type password: str | unicode
        """
        raise NotImplementedError()

    def set_forwarding(self, subscription_name, mail_account_name, is_enable_forwarding, forwarding_addresses):
        """Set forwarding for given mail account in target panel

        :type subscription_name: str | unicode
        :type mail_account_name: str | unicode
        :type is_enable_forwarding: bool
        :type forwarding_addresses: list[str]
        """
        raise NotImplementedError()

    def set_aliases(self, subscription_name, mail_account_name, aliases):
        """Set aliases for given mail account in target panel

        :type subscription_name: str | unicode
        :type mail_account_name: str | unicode
        :type aliases: list[str]
        """
        raise NotImplementedError

    def is_exists_by_subscription(self, subscription_name, mail_user_name, domain_name):
        """Check if mail account with given name exists in target panel

        :type subscription_name: str | unicode
        :type mail_user_name: str | unicode
        :type domain_name: str | unicode
        :rtype: bool
        """
        raise NotImplementedError()

    def is_mailbox_enabled(self, subscription_name, mail_user_name, domain_name):
        """Check if mail account with given name exists in target panel and mailbox is enabled for it

        Returns:
        - True, if mail account exists and mailbox is enabled
        - False, if mail account exists and mailbox is disabled
        - None, if mail account does not exists

        :type subscription_name: str | unicode
        :type mail_user_name: str | unicode
        :type domain_name: str | unicode
        :rtype: bool | None
        """
        raise NotImplementedError()

    def get_password(self, subscription_name, mail_user_name, domain_name):
        """Get password (encrypted) of mail account with given name

        Returns tuple (password, password type).

        :type subscription_name: str | unicode
        :type mail_user_name: str | unicode
        :type domain_name: str | unicode
        :rtype: tuple
        """
        raise NotImplementedError()

    def get_mailbox_effective_quota(self, subscription_name, mail_user_name, domain_name):
        """Get effective quota (according to mailbox limit and subscription limit) of mail account with given name

        Returns quota as string value.

        :type subscription_name: str | unicode
        :type mail_user_name: str | unicode
        :type domain_name: str | unicode
        :rtype: str
        """
        raise NotImplementedError()

    def get_list_by_domain(self, subscription_name, domain_name):
        """Retrieve list of mail accounts in panel for given domain

        :type subscription_name: str | unicode
        :type domain_name: str | unicode
        :rtype: list[parallels.core.hosting_repository.mail_account.MailAccountEntity]
        """
        raise NotImplementedError()


class MailAccountEntity(Entity):
    def __init__(self, short_name):
        """Class constructor

        :type short_name: str | unicode
        """
        self._short_name = short_name

    @property
    def short_name(self):
        """Mail account short name (everything before '@')

        :rtype: str | unicode
        """
        return self._short_name


class CreateMailAccountEntity(Entity):
    def __init__(self, name, password):
        """
        :type name: str | unicode
        :type password: str | unicode | None
        """
        self._name = name
        self._password = password

    @property
    def name(self):
        """
        :rtype: str | unicode
        """
        return self._name

    @property
    def password(self):
        """
        :rtype: str | unicode | None
        """
        return self._password
