class HostingRepositoryModel(object):
    @property
    def panel_user(self):
        """Model of panel users in hosting panel

        :rtype: parallels.core.hosting_repository.panel_user.PanelUserModel
        """
        raise NotImplementedError()

    @property
    def panel_user_role(self):
        """Model of panel user roles in hosting panel

        :rtype: parallels.core.hosting_repository.panel_user_role.PanelUserRoleModel
        """
        raise NotImplementedError()

    @property
    def reseller(self):
        """Model of resellers in hosting panel

        :rtype: parallels.core.hosting_repository.reseller.ResellerModel
        """
        raise NotImplementedError()

    @property
    def customer(self):
        """Model of customers in hosting panel

        :rtype: parallels.core.hosting_repository.customer.CustomerModel
        """
        raise NotImplementedError()

    @property
    def service_plan(self):
        """Model of service plans in hosting panel

        :rtype: parallels.core.hosting_repository.service_plan.ServicePlanModel
        """
        raise NotImplementedError()

    @property
    def service_plan_addon(self):
        """Model of service plan add-ons in hosting panel

        :rtype: parallels.core.hosting_repository.service_plan_addon.ServicePlanAddonModel
        """
        raise NotImplementedError()

    @property
    def subscription(self):
        """Model of subscription in hosting panel

        :rtype: parallels.core.hosting_repository.subscription.SubscriptionModel
        """
        raise NotImplementedError()

    @property
    def domain(self):
        """Model of domains in hosting panel

        :rtype: parallels.core.hosting_repository.domain.DomainModel
        """
        raise NotImplementedError()

    @property
    def subdomain(self):
        """Model of subdomain in hosting panel

        :rtype: parallels.core.hosting_repository.subdomain.SubdomainModel
        """
        raise NotImplementedError()

    @property
    def domain_alias(self):
        """Model of domain alises in hosting panel

        :rtype: parallels.core.hosting_repository.domain_alias.DomainAliasModel
        """
        raise NotImplementedError()

    @property
    def virtual_hosting_settings(self):
        """Model of virtual hosting settings of domains

        :rtype: parallels.core.hosting_repository.virtual_hosting_settings.VirtualHostingSettingsModel
        """
        raise NotImplementedError()


    @property
    def mail_account(self):
        """Model of mail accounts in hosting panel

        :rtype: parallels.core.hosting_repository.mail_account.MailAccountModel
        """
        raise NotImplementedError()

    @property
    def database(self):
        """Model of databases in hosting panel

        :rtype: parallels.core.hosting_repository.database.DatabaseModel
        """
        raise NotImplementedError()

    @property
    def database_user(self):
        """Model of database users in hosting panel

        :rtype: parallels.core.hosting_repository.database_user.DatabaseUserModel
        """
        raise NotImplementedError()

    @property
    def dns_record(self):
        """Model of DNS record in hosting panel

        :rtype: parallels.core.hosting_repository.dns_record.DnsRecordModel
        """
        raise NotImplementedError()

    @property
    def extension(self):
        """Model of extension of hosting panel

        :rtype: parallels.core.hosting_repository.extension.ExtensionModel
        """
        raise NotImplementedError()

    @property
    def panel(self):
        """Model of hosting panel

        :rtype: parallels.core.hosting_repository.panel.PanelModel
        """
        raise NotImplementedError()

    @property
    def tomcat(self):
        """Model of Java (Tomcat) applications
        
        :rtype: parallels.core.hosting_repository.tomcat.TomcatModel
        """
        raise NotImplementedError()
