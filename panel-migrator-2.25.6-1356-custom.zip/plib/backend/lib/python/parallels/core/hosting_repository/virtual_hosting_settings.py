from parallels.core.utils.entity import Entity


class VirtualHostingSettingsModel(object):
    def get_virtual_hosting_settings(self, subscription_name, domain_name):
        """Get virtual hosting settings of subscription

        :type subscription_name: str | unicode
        :type domain_name: str | unicode
        :rtype: parallels.core.hosting_repository.virtual_hosting_settings.VirtualHostingSettingsEntity | None
        """
        raise NotImplementedError()

    def set_web_server_additional_directives(self, subscription_name, domain_name, directives):
        """Set additional Apache/Nginx directives of domain
        
        :type subscription_name: str | unicode
        :type domain_name: str | unicode
        :type directives: parallels.core.hosting_repository.virtual_hosting_settings.WebServerDirectivesEntity
        :rtype: None 
        """
        raise NotImplementedError()


class VirtualHostingSettingsEntity(Entity):
    def __init__(self, document_root, sysuser_login, ip_addresses, hosting_ssl, domain_display_name):
        """
        :type document_root: str | unicode
        :type sysuser_login: str | unicode
        :type ip_addresses: list[str | unicode]
        :type hosting_ssl: bool
        :type hosting_ssl: str | unicode
        """
        self._document_root = document_root
        self._sysuser_login = sysuser_login
        self._ip_addresses = ip_addresses
        self._hosting_ssl = hosting_ssl
        self._domain_display_name = domain_display_name

    @property
    def document_root(self):
        """
        :rtype: str | unicode
        """
        return self._document_root

    @property
    def sysuser_login(self):
        """
        :rtype: str | unicode
        """
        return self._sysuser_login

    @property
    def ip_addresses(self):
        """
        :rtype: list[str | unicode]
        """
        return self._ip_addresses

    @property
    def hosting_ssl(self):
        """
        :rtype: bool
        """
        return self._hosting_ssl

    @property
    def domain_display_name(self):
        """
        :rtype: str | unicode
        """
        return self._domain_display_name


class WebServerDirectivesEntity(Entity):
    def __init__(self, apache_settings=None, apache_ssl_settings=None, nginx_settings=None):
        self._apache_settings = apache_settings
        self._apache_ssl_settings = apache_ssl_settings
        self._nginx_settings = nginx_settings

    @property
    def apache_settings(self):
        """
        :rtype: str | unicode | None 
        """
        return self._apache_settings

    @property
    def apache_ssl_settings(self):
        """
        :rtype: str | unicode | None 
        """
        return self._apache_ssl_settings

    @property
    def nginx_settings(self):
        """
        :rtype: str | unicode | None 
        """
        return self._nginx_settings
