class PanelUserRoleModel(object):
    def create(self, role, owner):
        """Create user role in target panel

        :type role: parallels.core.target_data_model.AuxiliaryUserRole
        :type owner: parallels.core.target_data_model.Client | parallels.core.target_data_model.Reseller
        """
        raise NotImplementedError()
