from parallels.core.utils.entity import Entity


class DatabaseModel(object):
    def create_from_dump(self, database_dump, subscription_name, is_assimilate=False):
        """Create database in target panel

        :type database_dump: parallels.core.dump.data_model.Database
        :type subscription_name: str
        :type is_assimilate: bool
        """
        raise NotImplementedError()

    def create(self, database, subscription_name):
        """Create database in target panel

        :type database: parallels.core.hosting_repository.database.CreateDatabaseEntity
        :type subscription_name: str | unicode
        :rtype: None
        """
        raise NotImplementedError()

    def is_exists_by_subscription(self, subscription_name, database_name):
        """Check if database with given name exists in target panel

        :type subscription_name: str
        :type database_name: str
        :rtype: bool
        """
        raise NotImplementedError()

    def get_list_by_subscription(self, subscription_name, db_type):
        """Retrieve list of databases in panel for given subscription

        :type subscription_name: str | unicode
        :type db_type: str | unicode
        :rtype: list[parallels.core.hosting_repository.database.DatabaseEntity]
        """
        raise NotImplementedError()


class CreateDatabaseEntity(Entity):
    def __init__(self, name, dbtype, host, port):
        """
        :type name: str | unicode
        :type dbtype: str | unicode
        :type host: str | unicode
        :type port: str | unicode
        """
        self._name = name
        self._dbtype = dbtype
        self._host = host
        self._port = port

    @property
    def name(self):
        """
        :rtype: str | unicode
        """
        return self._name

    @property
    def dbtype(self):
        """
        :rtype: str | unicode
        """
        return self._dbtype

    @property
    def host(self):
        """
        :rtype: str | unicode
        """
        return self._host

    @property
    def port(self):
        """
        :rtype: str | unicode
        """
        return self._port


class DatabaseEntity(Entity):
    def __init__(self, name, user_names):
        """Class constructor

        :type name: str | unicode
        :type users: list[str | unicode]
        """
        self._name = name
        self._user_names = user_names

    @property
    def name(self):
        """Database name

        :rtype: str | unicode
        """
        return self._name

    @property
    def user_names(self):
        """Database user names

        :rtype: list[str | unicode]
        """
        return self._user_names