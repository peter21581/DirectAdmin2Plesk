from parallels.core.utils.entity import Entity


class DatabaseUserModel(object):
    def create_from_dump(self, database_user_dump, subscription_name, is_assimilate=False):
        """Create database user in target panel

        :type database_user_dump: parallels.core.dump.data_model.DatabaseUser
        :type subscription_name: str
        :type is_assimilate: bool
        """
        raise NotImplementedError()

    def create(self, database_user, subscription_name):
        """Create database user in target panel

        :type database_user: parallels.core.hosting_repository.database_user.CreateDatabaseUserEntity
        :type subscription_name: str | unicode
        :return:
        """
        raise NotImplementedError()

    def is_exists_by_subscription(self, subscription_name, database_user_name):
        """Check if database user with given name exists in target panel

        :type subscription_name: str
        :type database_user_name: str
        :rtype: bool
        """
        raise NotImplementedError()


class CreateDatabaseUserEntity(Entity):
    PASSWORD_TYPE_PLAIN = 'plain'

    def __init__(self, name, password, password_type, database_name, dbtype, host, port):
        """
        :type name: str | unicode
        :type password: str | unicode
        :type password_type: str | unicode
        :type database_name: str | unicode
        :type dbtype: str | unicode
        :type host: str | unicode
        :type port: str | unicode
        """
        self._name = name
        self._password = password
        self._password_type = password_type
        self._database_name = database_name
        self._dbtype = dbtype
        self._host = host
        self._port = port

    @property
    def name(self):
        """
        :rtype: str | unicode
        """
        return self._name

    @property
    def password(self):
        """
        :rtype: str | unicode
        """
        return self._password

    @property
    def password_type(self):
        """
        :rtype: str | unicode
        """
        return self._password_type

    @property
    def database_name(self):
        """
        :rtype: str | unicode
        """
        return self._database_name

    @property
    def dbtype(self):
        """
        :rtype: str | unicode
        """
        return self._dbtype

    @property
    def host(self):
        """
        :rtype: str | unicode
        """
        return self._host

    @property
    def port(self):
        """
        :rtype: str | unicode
        """
        return self._port
