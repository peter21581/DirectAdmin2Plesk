from parallels.core.utils.entity import Entity


class DatabaseServerEntity(Entity):
    def __init__(self, database_server_id, host, port, type):
        self._database_server_id = database_server_id
        self._host = host
        self._port = port
        self._type = type

    @property
    def database_server_id(self):
        return self._database_server_id

    @property
    def host(self):
        return self._host

    @property
    def port(self):
        return self._port

    @property
    def type(self):
        return self._type
