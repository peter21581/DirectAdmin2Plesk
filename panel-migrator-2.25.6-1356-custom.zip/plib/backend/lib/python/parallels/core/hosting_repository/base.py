class BaseModel(object):
    def __init__(self):
        self._tracer = None

    def trace(self, tracer):
        """Set given tracer for this model

        :type tracer: parallels.core.utils.tracer.Tracer
        :rtype parallels.core.hosting_repository.base.BaseModel
        """
        self._tracer = tracer
        return self

    @property
    def tracer(self):
        return self._tracer
