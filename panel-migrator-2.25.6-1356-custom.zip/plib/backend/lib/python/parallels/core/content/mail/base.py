
class CopyMailBase(object):
    """Base interface to copy content method"""
    def copy_mail(self, global_context, subscription, issues):
        raise NotImplementedError()