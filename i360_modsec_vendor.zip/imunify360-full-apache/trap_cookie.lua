#!/usr/bin/lua
local function has_value (table, val)
    for index=1,#table do
        if table[index] == val then
            return true
        end
    end
    return false
end

local function concat_args(ARGS)
   local args = ""
   local skip_arguments = {"_wpnonce", "_wp_http_referer"}

   for k,v in pairs(ARGS) do
        name = v["name"];
        name = string.gsub(name, "REQUEST_HEADERS:Cookie(.*)", "%1");
        if not has_value(skip_arguments, name) then
            value = v["value"];
            args = name .. "=" .. value .."&";
        end
   end

   return args;

end

function main()
   local args_cookie = concat_args(m.getvars("REQUEST_HEADERS.cookie"));

   m.setvar("TX.cookie_trapped", "1");
   m.setvar("TX.cook_info", " C:" .. args_cookie);
   return nil;
end