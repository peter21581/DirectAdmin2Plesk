function file_exists(name)
	local f=io.open(name,"r")
	if f~=nil then 
		io.close(f) 
		return true 
	else 
		return false 
	end
end
function check_scan_enabled()
	local f = io.open("/etc/sysconfig/imunify360/imunify360-merged.config","rb")  -- new config path
	if f == nil then  -- fallback to the old config path
		f = io.open("/etc/sysconfig/imunify360/imunify360.config","rb")
		if f == nil then  -- no config found, exit as before this change
			return false
		end
	end

	if f ~= nil then
		local content = f:read("*all")
		io.close(f)
		if string.match(content, 'enable_scan_modsec:%strue') then
			return true
		end
	else
		return false
	end
	return false
end
function main(filename)
	local scan_script

	-- Check if modsec scan enabled in config file
	if not check_scan_enabled() then
		return nil
	end

	-- Check if scan script exist, if not - do nothing
	if file_exists("/usr/share/imunify360/scripts/modsec_scan_real.py") then
		scan_script = "/usr/share/imunify360/scripts/modsec_scan_real.py"
	elseif file_exists("/opt/alt/python35/share/imunify360/scripts/modsec_scan_real.py") then
		scan_script = "/opt/alt/python35/share/imunify360/scripts/modsec_scan_real.py"
	else return nil
	end

	-- Execute scan script and get a output as a result
	local handle = io.popen(scan_script .. " " .. filename)
	local scan_result = handle:read("*a")
	handle:close()
	-- Check if scan script return something useful
	-- 1 OK - means OK, no malware found
	-- 0 Attempt to upload malware - means harmful file
	-- empty string or any other output means error or execution failure, and do nothing
	if string.match(scan_result, '0 Attempt to upload malware') then
		return 1
	elseif string.match(scan_result, '1 OK') then
		return nil
	end
	return nil
end