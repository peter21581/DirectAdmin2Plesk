#!/usr/bin/lua
function main()
   m.setvar("TX.lua_present", "1");
   return nil;
end