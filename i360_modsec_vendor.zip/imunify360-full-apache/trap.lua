#!/usr/bin/lua

local function has_value (table, val)
    for index=1,#table do
        if table[index] == val then
            return true
        end
    end
    return false
end

local function shorten(value, maxlen)
    if (string.len(value) > maxlen) and (maxlen > 3) then
        return string.sub(value, 1, maxlen - 3) .. "..."
    else
        return value
    end
end

local function concat_args(ARGS)
   local args = ""
   local skip_arguments = {"_wpnonce", "_wp_http_referer"}

   for k,v in pairs(ARGS) do
        name = v["name"];
        name = string.gsub(name, "ARGS_GET:(.*)", "%1");
        name = string.gsub(name, "ARGS_POST:(.*)", "%1");
        name = string.gsub(name, "FILES:(.*)", "%1");
        if not has_value(skip_arguments, name) then
            value = v["value"];
            --m.log(1, "Arg Name: " ..name.. " and Value: " ..value.. ".");
            if string.len(args) < 1000 then
                args = args .. shorten(name, 20) .. "=" .. shorten(value, 200) .."&";
            end
        end
   end

   return args;

end

function main()
   local args_get = concat_args(m.getvars("ARGS_GET"));
   local args_post = concat_args(m.getvars("ARGS_POST"));
   local args_file = concat_args(m.getvars("FILES"));

   m.setvar("TX.trapped", "1");
   m.setvar("TX.trapinfo", "G:" .. args_get .. " P:" .. args_post .. " F:" .. args_file);
   return nil;
end
